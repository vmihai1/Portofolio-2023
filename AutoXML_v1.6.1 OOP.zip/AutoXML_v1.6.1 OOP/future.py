#Future versions

# def change_ip():
#     window1 = Tk()
#     window1.title('Change IP addresses')
#     window1.geometry('{}x{}'.format(300, 100))
#     window1.config(background="white")

# def change_specific_ip():
#     window2 = Tk()
#     window2.title('Change specific 4G addresses')
#     window2.geometry('{}x{}'.format(500, 280))
#     window2.config(background="white")
#     OaM_IP = StringVar(window2)
#     OaM_SNM, OaM_DR, CUP_IP, CUP_SNM, CUP_DR, Sync_IP, Sync_SNM, Sync_DR, Sync_Source, Sync_Source_SNM, CUP_INNER_IP, CUP_INNER_SNM, SecGW_IP = \
#     StringVar(window2), StringVar(window2), StringVar(window2), StringVar(window2), StringVar(window2), StringVar(window2), StringVar(window2), StringVar(window2), StringVar(window2), StringVar(window2), StringVar(window2), StringVar(window2), StringVar(window2)
#
#     #Collect old IP addresses:
#     ACLRULE_var1 = parse_existing_MO_name(root, 'ACLRULE')
#     ACLRULE_4G_inner_unique = []
#     for i in ACLRULE_var1:
#         for j in i:
#             for j in range(0, len(ACLRULE_var1)):
#                 flag_4G_inner = False
#                 for item in ACLRULE_var1[j]:
#                     for key in item.keys():
#                         if key == 'ACLID' and item[key] == '3300':
#                             flag_4G_inner = True
#                         if flag_4G_inner and key == 'SIP':
#                             if item[key] not in ACLRULE_4G_inner_unique:
#                                 ACLRULE_4G_inner_unique.append(item[key])
#     try:
#         S1_4G_inner_old = ACLRULE_4G_inner_unique[0]
#         print(S1_4G_inner_old)
#     except:
#         pass
#
#     ACLRULE_5G_inner_unique = []
#     for i in ACLRULE_var1:
#         for j in i:
#             for j in range(0, len(ACLRULE_var1)):
#                 flag_5G_inner = False
#                 for item in ACLRULE_var1[j]:
#                     for key in item.keys():
#                         if key == 'ACLID' and item[key] == '3301':
#                             flag_5G_inner = True
#                         if flag_5G_inner and key == 'SIP':
#                             if item[key] not in ACLRULE_5G_inner_unique:
#                                 ACLRULE_5G_inner_unique.append(item[key])
#     try:
#         S1_5G_inner_old = ACLRULE_5G_inner_unique[0]
#         print(S1_5G_inner_old)
#     except:
#         pass
#
#     OMCH_var1 = parse_existing_MO_name(root, 'OMCH')
#     OMCH_localip_unique = []
#     for i in OMCH_var1:
#         for j in i:
#             for j in range(0, len(OMCH_var1)):
#                 for item in OMCH_var1[j]:
#                     for key in item.keys():
#                         if key == 'IP':
#                             if item[key] not in OMCH_localip_unique:
#                                 OMCH_localip_unique.append(item[key])
#     try:
#         OMCH_ip_old = OMCH_localip_unique[0]
#         print(OMCH_ip_old)
#     except:
#         pass
#
#     Sync_var1 = parse_existing_MO_name(root, 'IPCLKLNK')
#     Sync_localip_unique = []
#     Sync_source_unique=[]
#     for i in Sync_var1:
#         for j in i:
#             for j in range(0, len(Sync_var1)):
#                 for item in Sync_var1[j]:
#                     for key in item.keys():
#                         if key == 'CIP':
#                             if item[key] not in Sync_localip_unique:
#                                 Sync_localip_unique.append(item[key])
#                         if key == 'SIP':
#                             if item[key] not in Sync_source_unique:
#                                 Sync_source_unique.append(item[key])
#     try:
#         Sync_ip_old = Sync_localip_unique[0]
#         print(Sync_ip_old)
#         Sync_source_old=Sync_source_unique[0]
#         print(Sync_source_old)
#     except:pass
#
#     Certreq_var1=parse_existing_MO_name(root, 'CERTREQ')
#     S1_4G_outer_unique=[]
#     for i in Certreq_var1:
#         for j in i:
#             for j in range(0, len(Certreq_var1)):
#                 for item in Certreq_var1[j]:
#                     for key in item.keys():
#                         if key == 'LOCALIP':
#                             if item[key] not in S1_4G_outer_unique:
#                                 S1_4G_outer_unique.append(item[key])
#     try:
#         S1_4G_outer_old = S1_4G_outer_unique[0]
#         print(S1_4G_outer_old)
#     except:pass
#
#     Ikepeer_var1=parse_existing_MO_name(root, 'IKEPEER')
#     Ikepeer_4G_unique=[]
#     for i in Ikepeer_var1:
#         for j in i:
#             for j in range(0, len(Ikepeer_var1)):
#                 flag_4G_ikepeer = False
#                 for item in Ikepeer_var1[j]:
#                     for key in item.keys():
#                         if key == 'PEERNAME' and item[key] == 's1x2peer':
#                             flag_4G_ikepeer = True
#                         if flag_4G_ikepeer and key == 'REMOTEIP':
#                             if item[key] not in Ikepeer_4G_unique:
#                                 Ikepeer_4G_unique.append(item[key])
#     try:
#         Ikepeer_4G_old = Ikepeer_4G_unique[0]
#         print(Ikepeer_4G_old)
#     except:pass
#
#     # Vlanmap_legacy_var1=parse_existing_MO_name(root, 'VLANMAP')
#     # Nexthop_4g_legacy_unique=[]
#     # Nexthop_sync_legacy_unique=[]
#     # Nexthop_oam_legacy_unique=[]
#     # for i in Vlanmap_legacy_var1:
#     #     for j in i:
#     #         for j in range(0, len(Vlanmap_legacy_var1)):
#     #             flag_4G_ikepeer = False
#     #             for item in Vlanmap_legacy_var1[j]:
#     #                 for key in item.keys():
#     #                     if key == 'VLANID' and item[key] in []:
#     #                         flag_4G_ikepeer = True
#     #                     if flag_4G_ikepeer and key == 'REMOTEIP':
#     #                         if item[key] not in Ikepeer_4G_unique:
#     #                             Ikepeer_4G_unique.append(item[key])
#
#     Iprt_legacy_var1=parse_existing_MO_name(root, 'IPRT')
#     Nexthop_4G_legacy_unique=[]
#     Nexthop_sync_legacy_unique=[]
#     Nexthop_oam_legacy_unique=[]
#
#
#     def submit():
#         CUP_IP_value = CUP_IP.get()
#         CUP_SNM_value = CUP_SNM.get()
#         CUP_DR_value = CUP_DR.get()
#         CUP_INNER_IP_value = CUP_INNER_IP.get()
#         CUP_INNER_SNM_value = CUP_INNER_SNM.get()
#         SecGW_IP_value=SecGW_IP.get()
#         OaM_IP_value = OaM_IP.get()
#         OaM_SNM_value = OaM_SNM.get()
#         OaM_DR_value = OaM_DR.get()
#         Sync_IP_value = Sync_IP.get()
#         Sync_SNM_value = Sync_SNM.get()
#         Sync_DR_value = Sync_DR.get()
#         Sync_Source_value = Sync_Source.get()
#         Sync_Source_SNM_value = Sync_Source_SNM.get()
#
#         print("CUP_IP : " + CUP_IP_value)
#         print("CUP_SNM : " + CUP_SNM_value)
#         print("CUP_DR : " + CUP_DR_value)
#         print("CUP_INNER : " + CUP_INNER_IP_value)
#         print("CUP_INNER_SNM : " + CUP_INNER_SNM_value)
#         print("SecGW_IP : " + SecGW_IP_value)
#         print("OaM_IP : " + OaM_IP_value)
#         print("OaM_SNM : " + OaM_SNM_value)
#         print("OaM_DR : " + OaM_DR_value)
#         print("Sync_IP : " + Sync_IP_value)
#         print("Sync_SNM : " + Sync_SNM_value)
#         print("Sync_DR : " + Sync_DR_value)
#         print("Sync_Source : " + Sync_Source_value)
#         print("CUP_IP : " + CUP_IP_value)
#         print("Sync_Source_SNM : " + Sync_Source_SNM_value)
#
#
#
#
#
#         # for child0 in root:
#         #     for child1 in child0:
#         #         for child2 in child1:
#         #             if child2.tag == '' + 'OMCH':
#         #                 for child3 in child2:
#         #                     for child4 in child3:
#         #                         if child4.tag == 'IP' and OaM_IP_value.count('.')==3 and ' ' not in OaM_IP_value:
#         #                             child4.text =OaM_IP_value
#         #                             # ET.dump(child1)
#         #                             break
#         # tree.write(OUTPUT)
#         # for child0 in root:
#         #     for child1 in child0:
#         #         for child2 in child1:
#         #             if child2.tag == '' + 'OMCH':
#         #                 for child3 in child2:
#         #                     for child4 in child3:
#         #                         if child4.tag == 'MASK' and OaM_SNM_value.count('.')==3 and ' ' not in OaM_SNM_value:
#         #                             child4.text =OaM_SNM_value
#         #                             # ET.dump(child1)
#         #                             break
#         # tree.write(OUTPUT)
#         # time.sleep(10)
#         # window2.destroy()
#
#     def label_text_grid(txt,col,row_label,row_text,ip_var):
#         """creates label and text widgets for this window"""
#
#         #name_var.set("")
#         label=Label(window2,text=txt,bg='white').grid(column=col, row=row_label, sticky="W")
#         entry=Entry(window2, textvariable = ip_var, font=("arial", 10))
#         entry.grid(column=col, row=row_text, sticky="W")
#         #return label, entry
#
#     sub_btn = Button(window2, text='Submit', command=submit)
#     label_text_grid('CUP_IP',1,1,2,CUP_IP)
#     # Label(window2, text='CUP_IP').grid(column=1, row=1, sticky="W")
#     # entry = Entry(window2, textvariable=CUP_IP, font=("arial", 10))
#     # entry.grid(row=2,column=1, sticky="W")
#     label_text_grid('CUP_SNM', 2, 1, 2,CUP_SNM)
#     label_text_grid('CUP_DR',3,1,2,CUP_DR)
#     label_text_grid('CUP_INNER_IP', 1, 3, 4,CUP_INNER_IP)
#     label_text_grid('CUP_INNER_SNM', 2, 3, 4,CUP_INNER_SNM)
#     label_text_grid('SecGW_IP', 1, 5, 6,SecGW_IP)
#     label_text_grid('Sync_IP', 1, 7, 8,Sync_IP)
#     label_text_grid('Sync_SNM', 2, 7, 8,Sync_SNM)
#     label_text_grid('Sync_DR', 3, 7, 8,Sync_DR)
#     label_text_grid('Sync_Source', 1, 9, 10,Sync_Source)
#     label_text_grid('Sync_Source_SNM', 2, 9, 10,Sync_Source_SNM)
#     label_text_grid('OaM_IP', 1, 11, 12,OaM_IP)
#     label_text_grid('OaM_SNM', 2, 11, 12,OaM_SNM)
#     label_text_grid('OaM_DR', 3, 11, 12,OaM_DR)
#
#
#     sub_btn.grid(row=13, column=1)
#     window2.mainloop()

    # def change_csv_all_ip():
    #     filename3 = filedialog.askopenfilename(initialdir="/C:/", title="Select a File",filetypes=(("CSV files", "*.csv*"), ("all files", "*.*")))
    #     fo_csv=open(filename3,'r')
    #     csvreader = csv.reader(fo_csv, delimiter=';', quotechar='|')
    #     for row in csvreader:
    #         #print(', '.join(row))
    #         print(row)
    #         print(len(row))
    #
    #     OaM_IP = ''
    #     OaM_SNM = ''
    #     OaM_DR = ''
    #     CUP_IP = ''
    #     CUP_SNM = ''
    #     CUP_DR = ''
    #     Sync_IP = ''
    #     Sync_SNM = ''
    #     Sync_DR = ''
    #     Sync_Source = ''
    #     Sync_Source_SNM = ''
    #     CUP_INNER_IP = ''
    #     CUP_INNER_SNM = ''
    # # filename3 = filedialog.askopenfilename(initialdir="/C:/", title="Select a File",filetypes=(("CSV files", "*.csv*"), ("all files", "*.*")))
    # # fo_csv=open(filename3,'r')
    # # csvreader = csv.reader(fo_csv, delimiter=';', quotechar='|')
    # # for row in csvreader:
    # #     #print(', '.join(row))
    # #     print(row)
    # #     print(len(row))
    # #
    #Button_ip_1=Button(window2, text="Change specific 4G IP", command=change_specific_ip, width=30)
    #Button_ip_1.grid(column=1, row=1, sticky="W")
    # Button_ip_2=Button(window1, text="Change CSV IP", command=change_csv_all_ip, width=30)
    # Button_ip_2.grid(column=1, row=2, sticky="W")

def insert_IPADDR4(ITFID,IP,MASK,VRFIDX,USERLABEL):
    child2_tag_list_unique=[]
    for child0 in root:
        for child1 in child0:
            for child2 in child1:
                if child2.tag not in child2_tag_list_unique:
                    child2_tag_list_unique.append(child2.tag)

    for child0 in root:
        for child1 in child0:
            for child2 in child1:
                if child2.tag == '' + 'VRF':    #will create a new class under same parent as 'VRF' object
                    if 'IPADDR4' not in child2_tag_list_unique:
                        new_class_IPADDR4_subelement0 = ET.SubElement(child0, 'class')
                        new_class_IPADDR4_subelement1 = ET.SubElement(new_class_IPADDR4_subelement0, 'IPADDR4')
                        new_class_IPADDR4_subelement2 = ET.SubElement(new_class_IPADDR4_subelement1, 'attributes')
                        new_class_IPADDR4_subelement3 =  ET.SubElement(new_class_IPADDR4_subelement2, 'ITFD')
                        new_class_IPADDR4_subelement3.text=str(ITFID)
                        new_class_IPADDR4_subelement3 = ET.SubElement(new_class_IPADDR4_subelement2, 'IP')
                        new_class_IPADDR4_subelement3.text = str(IP)
                        new_class_IPADDR4_subelement3 = ET.SubElement(new_class_IPADDR4_subelement2, 'MASK')
                        new_class_IPADDR4_subelement3.text = str(MASK)
                        new_class_IPADDR4_subelement3 = ET.SubElement(new_class_IPADDR4_subelement2, 'VRFIDX')
                        new_class_IPADDR4_subelement3.text = str(VRFIDX)
                        new_class_IPADDR4_subelement3 = ET.SubElement(new_class_IPADDR4_subelement2, 'USERLABEL')
                        new_class_IPADDR4_subelement3.text = str(USERLABEL)
                        break
                    else:
                        for child0 in root:
                            for child1 in child0:
                                for child2 in child1:
                                    if child2.tag == '' + 'IPADDR4':
                                        new_class_IPADDR4_subelement0 = ET.SubElement(child1, 'IPADDR4')
                                        new_class_IPADDR4_subelement1 = ET.SubElement(new_class_IPADDR4_subelement0, 'attributes')
                                        new_class_IPADDR4_subelement2 = ET.SubElement(new_class_IPADDR4_subelement1,'ITFD')
                                        new_class_IPADDR4_subelement2.text = str(ITFID)
                                        new_class_IPADDR4_subelement2 = ET.SubElement(new_class_IPADDR4_subelement1,'IP')
                                        new_class_IPADDR4_subelement2.text = str(IP)
                                        new_class_IPADDR4_subelement2 = ET.SubElement(new_class_IPADDR4_subelement1,'MASK')
                                        new_class_IPADDR4_subelement2.text = str(MASK)
                                        new_class_IPADDR4_subelement2 = ET.SubElement(new_class_IPADDR4_subelement1,'VRFIDX')
                                        new_class_IPADDR4_subelement2.text = str(VRFIDX)
                                        new_class_IPADDR4_subelement2 = ET.SubElement(new_class_IPADDR4_subelement1,'USERLABEL')
                                        new_class_IPADDR4_subelement2.text = str(USERLABEL)
                                        break
    tree.write(OUTPUT)
def insert_IPROUTE4(RTIDX,VRFIDX,DSTIP,DSTMASK,NEXTHOP,USERLABEL):
    child2_tag_list_unique = []
    for child0 in root:
        for child1 in child0:
            for child2 in child1:
                if child2.tag not in child2_tag_list_unique:
                    child2_tag_list_unique.append(child2.tag)

    for child0 in root:
        for child1 in child0:
            for child2 in child1:
                if child2.tag == '' + 'VRF':  # will create a new class under same parent as 'VRF' object ,select correctly the syndata object
                    if 'IPROUTE4' not in child2_tag_list_unique:
                        new_class_IPADDR4_subelement0 = ET.SubElement(child0, 'class')
                        new_class_IPADDR4_subelement1 = ET.SubElement(new_class_IPADDR4_subelement0, 'IPROUTE4')
                        new_class_IPADDR4_subelement2 = ET.SubElement(new_class_IPADDR4_subelement1, 'attributes')
                        new_class_IPADDR4_subelement3 = ET.SubElement(new_class_IPADDR4_subelement2, 'RTIDX')
                        new_class_IPADDR4_subelement3.text = str(RTIDX)
                        new_class_IPADDR4_subelement3 = ET.SubElement(new_class_IPADDR4_subelement2, 'VRFIDX')
                        new_class_IPADDR4_subelement3.text = str(VRFIDX)
                        new_class_IPADDR4_subelement3 = ET.SubElement(new_class_IPADDR4_subelement2, 'DSTIP')
                        new_class_IPADDR4_subelement3.text = str(DSTIP)
                        new_class_IPADDR4_subelement3 = ET.SubElement(new_class_IPADDR4_subelement2, 'DSTMASK')
                        new_class_IPADDR4_subelement3.text = str(DSTMASK)
                        new_class_IPADDR4_subelement3 = ET.SubElement(new_class_IPADDR4_subelement2, 'RTTYPE')
                        new_class_IPADDR4_subelement3.text = str(0)
                        new_class_IPADDR4_subelement3 = ET.SubElement(new_class_IPADDR4_subelement2, 'NEXTHOP')
                        new_class_IPADDR4_subelement3.text = str(NEXTHOP)
                        new_class_IPADDR4_subelement3 = ET.SubElement(new_class_IPADDR4_subelement2, 'MTUSWITCH')
                        new_class_IPADDR4_subelement3.text = str(0)
                        new_class_IPADDR4_subelement3 = ET.SubElement(new_class_IPADDR4_subelement2, 'PREF')
                        new_class_IPADDR4_subelement3.text = str(60)
                        new_class_IPADDR4_subelement3 = ET.SubElement(new_class_IPADDR4_subelement2, 'USERLABEL')
                        new_class_IPADDR4_subelement3.text = str(USERLABEL)
                        break
                    else:
                        for child0 in root:
                            for child1 in child0:
                                for child2 in child1:
                                    if child2.tag == '' + 'IPROUTE4':
                                        new_class_IPADDR4_subelement0 = ET.SubElement(child1, 'IPROUTE4')
                                        new_class_IPADDR4_subelement1 = ET.SubElement(new_class_IPADDR4_subelement0,'attributes')
                                        new_class_IPADDR4_subelement2 = ET.SubElement(new_class_IPADDR4_subelement1,'RTIDX')
                                        new_class_IPADDR4_subelement2.text = str(RTIDX)
                                        new_class_IPADDR4_subelement2 = ET.SubElement(new_class_IPADDR4_subelement1,'VRFIDX')
                                        new_class_IPADDR4_subelement2.text = str(VRFIDX)
                                        new_class_IPADDR4_subelement2 = ET.SubElement(new_class_IPADDR4_subelement1,'DSTIP')
                                        new_class_IPADDR4_subelement2.text = str(DSTIP)
                                        new_class_IPADDR4_subelement2 = ET.SubElement(new_class_IPADDR4_subelement1,'DSTMASK')
                                        new_class_IPADDR4_subelement2.text = str(DSTMASK)
                                        new_class_IPADDR4_subelement2 = ET.SubElement(new_class_IPADDR4_subelement1,'RTTYPE')
                                        new_class_IPADDR4_subelement2.text = str(0)
                                        new_class_IPADDR4_subelement2 = ET.SubElement(new_class_IPADDR4_subelement1,'NEXTHOP')
                                        new_class_IPADDR4_subelement2.text = str(NEXTHOP)
                                        new_class_IPADDR4_subelement2 = ET.SubElement(new_class_IPADDR4_subelement1,'MTUSWITCH')
                                        new_class_IPADDR4_subelement2.text = str(0)
                                        new_class_IPADDR4_subelement2 = ET.SubElement(new_class_IPADDR4_subelement1,'PREF')
                                        new_class_IPADDR4_subelement2.text = str(60)
                                        new_class_IPADDR4_subelement2 = ET.SubElement(new_class_IPADDR4_subelement1,'USERLABEL')
                                        new_class_IPADDR4_subelement2.text = str(USERLABEL)
                                        break
    tree.write(OUTPUT)
def old2new_basic_transmission_model_convertor():
    # GTRANSPARA mod
    # ETHPORT mod
    # IPADDR4 add
    # IPROUTE4 add
    # INTERFACE add
    # IPSECBINDITF add
    # DEVIP rmv
    # IPRT rmv
    # VLANMAP rmv
    # IPSECBIND rmv

    devip_ip_list=[]
    devip_mask_list=[]
    devip_userlabel_list=[]
    iprt_rtidx_list=[]
    iprt_destip_list=[]
    iprt_destmask_list=[]
    iprt_nexthop_list=[]
    iprt_descri_list=[]
    PN_list_unique = []
    for child0 in root:
        for child1 in child0:
            for child2 in child1:
                if child2.tag == '' + 'DEVIP':
                    for child3 in child2:
                        for child4 in child3:
                            if child4.tag == 'PN' and child4.text not in PN_list_unique:
                                PN_list_unique.append(child4.text)
                                # ET.dump(child1)
                                break
    for child0 in root:
        for child1 in child0:
            for child2 in child1:
                if child2.tag == '' + 'DEVIP':
                    for child3 in child2:
                        for child4 in child3:
                            if child4.tag == 'IP':
                                devip_ip_list.append(child4.text)
                            if child4.tag == 'MASK':
                                devip_mask_list.append(child4.text)
                            if child4.tag == 'USERLABEL':
                                devip_userlabel_list.append(child4.text)

    for child0 in root:
        for child1 in child0:
            for child2 in child1:
                if child2.tag == '' + 'IPRT':
                    for child3 in child2:
                        for child4 in child3:
                            if child4.tag == 'RTIDX':
                                iprt_rtidx_list.append(child4.text)
                            if child4.tag == 'DSTIP':
                                iprt_destip_list.append(child4.text)
                            if child4.tag == 'DSTMASK':
                                iprt_destmask_list.append(child4.text)
                            if child4.tag == 'NEXTHOP':
                                iprt_nexthop_list.append(child4.text)
                            if child4.tag == 'DESCRI':
                                iprt_descri_list.append(child4.text)


    # create a list with the interfaces, create the interfaces, replace cnt from 1st arg  in function call insert_IPADDR4

    for cnt in range(0,len(devip_ip_list)):
        insert_IPADDR4(cnt,devip_ip_list[cnt],devip_mask_list[cnt],'0', devip_userlabel_list[cnt])

    for cnt in range(0,len(iprt_destip_list)):
        insert_IPROUTE4(iprt_rtidx_list[cnt],0,iprt_destip_list[cnt],iprt_rtidx_list[cnt],iprt_nexthop_list[cnt],iprt_descri_list[cnt])
    # insert_IPADDR4(0, devip_ip_list[0], devip_mask_list[0], '0', devip_userlabel_list[0])
    # insert_IPADDR4(1, devip_ip_list[1], devip_mask_list[1], '0', devip_userlabel_list[1])
    # insert_IPADDR4(2, devip_ip_list[2], devip_mask_list[2], '0', devip_userlabel_list[2])
    # insert_IPADDR4(3, devip_ip_list[3], devip_mask_list[3], '0', devip_userlabel_list[3])



    """<class>
   <IPADDR4>
    <attributes>
     <ITFID>0</ITFID>
     <IP>172.26.100.238</IP>
     <MASK>255.255.254.0</MASK>
     <VRFIDX>0</VRFIDX>
     <USERLABEL>S1_X2 Inner IP</USERLABEL>
    </attributes>
   </IPADDR4>
   <IPADDR4>
    <attributes>
     <ITFID>1</ITFID>
     <IP>10.125.245.163</IP>
     <MASK>255.255.255.224</MASK>
     <VRFIDX>0</VRFIDX>
     <USERLABEL>OM local IP</USERLABEL>
    </attributes>
   </IPADDR4>
   <IPADDR4>
    <attributes>
     <ITFID>2</ITFID>
     <IP>192.170.3.218</IP>
     <MASK>255.255.255.252</MASK>
     <VRFIDX>0</VRFIDX>
     <USERLABEL>IPCLK local</USERLABEL>
    </attributes>
   </IPADDR4>
   <IPADDR4>
    <attributes>
     <ITFID>3</ITFID>
     <IP>192.168.50.19</IP>
     <MASK>255.255.254.0</MASK>
     <VRFIDX>0</VRFIDX>
     <USERLABEL>S1_X2 Outer IP</USERLABEL>
    </attributes>
   </IPADDR4>
  </class>"""

    for child0 in root:
        for child1 in child0:
            for child2 in child1:
                if child2.tag == '' + 'GTRANSPARA':
                    for child3 in child2:
                        for child4 in child3:
                            if child4.tag == 'TRANSCFGMODE' and child4.text == str(0):
                                child4.text = str(1)
    for child0 in root:
        for child1 in child0:
            for child2 in child1:
                if child2.tag == '' + 'ETHPORT':
                    for child3 in child2:
                        for child4 in child3:
                            if child4.tag == 'PORTID':
                                if '0' in PN_list_unique:
                                    child4.text = str(70)
                                elif '1' in PN_list_unique:
                                    child4.text = str(71)

    tree.write(OUTPUT)
