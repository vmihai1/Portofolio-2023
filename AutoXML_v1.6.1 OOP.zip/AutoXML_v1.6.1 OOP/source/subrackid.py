from source.parseMO import Mo


class Subrack(Mo):

    def change_bbu_subrack_id(self):
        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    for child3 in child2:
                        for child4 in child3:
                            if (child4.tag == 'SRN' and child4.text == str(0)) \
                                    or (child4.tag == 'HSRN' and child4.text == str(0)):
                                child4.text = str(1)
                                break
        self.tree.write(self.output)

    def change_basebandeqm_subrack_id(self):
        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == 'BASEBANDEQM':
                        for child3 in child2:
                            for child4 in child3:
                                for child5 in child4:
                                    for child6 in child5:
                                        if child6.tag == 'SRN' and child6.text == str(0):
                                            child6.text = str(1)
        self.tree.write(self.output)

    def change_bbu_subrack_id10(self):
        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    for child3 in child2:
                        for child4 in child3:
                            if (child4.tag == 'SRN' and child4.text == str(1)) \
                                    or (child4.tag == 'HSRN' and child4.text == str(1)) \
                                    or (child4.tag == 'SSRN' and child4.text == str(1)):
                                child4.text = str(0)
                                break
        self.tree.write(self.output)
