import xml.etree.ElementTree as ET
from source.parseMO import Mo
from source.templatefunctionsMO import rmv_old_mo


class Upeu(Mo):

    def rmv_old_ueiu(self):
        rmv_old_mo(self.root, 'UEIU', 'SN', '18')
        self.tree.write(self.output)

    def insert_new_upeu(self, cn, srn, sn):
        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'PEU':
                        subelement0 = ET.SubElement(child1, 'PEU')
                        subelement1 = ET.SubElement(subelement0, 'attributes')
                        ET.SubElement(subelement1, 'CN').text = str(cn)
                        ET.SubElement(subelement1, 'SRN').text = str(srn)
                        ET.SubElement(subelement1, 'SN').text = str(sn)
                        break
        self.tree.write(self.output)
