BBP_xml_string = '''<BBP>
			<attributes>
				<CN>0</CN>
				<SRN>1</SRN>
				<SN>4</SN>
				<TYPE>2</TYPE><!--UBBP-->
				<OVERLOADALMRPTTHLD>90</OVERLOADALMRPTTHLD>
				<OVERLOADALMCLRTHLD>85</OVERLOADALMCLRTHLD>
				<WM>14</WM><!--Normal-->
				<ADMSTATE>1</ADMSTATE><!--Unblocked-->
				<TIME>0</TIME>
				<BLKTP>0</BLKTP><!--Immediate-->
				<HCE>255</HCE><!--FULL-->
				<CPRIEX>0</CPRIEX><!--OFF-->
				<BRDSPEC></BRDSPEC>
				<CCNE>1</CCNE><!--ON-->
				<BBWS>20</BBWS><!-- GSM:NO;UMTS:NO;LTE FDD:YES;LTE TDD:NO;NB-IoT:YES;NR:NO -->
				<SRT>0</SRT><!--Default-->
				<CPRIEXMODE>0</CPRIEXMODE><!--FRONT PANEL EXTENSION-->
				<CPRIITFTYPE>0</CPRIITFTYPE><!--CPRI_SFP-->
				<CELLDEPLOY>2</CELLDEPLOY><!--PERFORMANCE-->
				<EXFUNCSW>0</EXFUNCSW><!-- COORD_OUTPUT_BACKHAUL_PT:OFF -->
				<LTEFLEXSPECSW>0</LTEFLEXSPECSW><!--OFF-->
			</attributes>
		</BBP>
'''
CPRIPORT_xml_string = '''<CPRIPORT>
		<attributes>
			<CN>0</CN>
			<SRN>1</SRN>
			<SN>3</SN>
			<OPTN>1</OPTN>
			<ADMINISTRATIVESTATE>1</ADMINISTRATIVESTATE>
			<PT>8</PT>
			<SPN>0</SPN>
			<SFPSW>1</SFPSW>
		</attributes>
	</CPRIPORT>'''

SFP_xml_string = '''<SFP>
		<attributes>
			<CN>0</CN>
			<SRN>1</SRN>
			<SN>4</SN>
			<MODULEID>5</MODULEID>
			<PT>8</PT>
		</attributes>
	</SFP>'''

CASCADEPORT_xml_string = '''<CASCADEPORT>
         <attributes>
          <CN>0</CN>
          <SRN>1</SRN>
          <SN>2</SN>
          <PN>6</PN>
          <PT>1</PT>
          <SW>0</SW>
          <PM>3</PM>
         </attributes>
    </CASCADEPORT>'''

SECTOR_xml_string = '''<SECTOR>
            <attributes>
                <SECTORID>20</SECTORID>
                <SECNAME>sector_20</SECNAME>
                <LOCATIONNAME>Sector_20</LOCATIONNAME>
                <USERLABEL>%omniFlag::false%</USERLABEL>
                <ANTAZIMUTH>65535</ANTAZIMUTH>
                <OLDSECTORID>65535</OLDSECTORID>
                <SECTORIDFORCONVERSION>65535</SECTORIDFORCONVERSION>
                <SECTORTYPEUMTS>255</SECTORTYPEUMTS><!--NULL-->
                <RXANTNUM>255</RXANTNUM>
                <DIVMODE>255</DIVMODE><!--NULL-->
                <COVERTYPE>255</COVERTYPE><!--NULL-->
                <RFCONNMODE>255</RFCONNMODE><!--NULL-->
                <SECTORMODELTE>255</SECTORMODELTE><!--NULL-->
                <ANTENNAMODE>255</ANTENNAMODE><!--NULL-->
                <SECTORCOMBIND>255</SECTORCOMBIND><!--NULL-->
                <OMNIFLAG>255</OMNIFLAG><!--NULL-->
                <ORIENTOFMAJORAXIS>255</ORIENTOFMAJORAXIS>
                <CONFIDENCE>255</CONFIDENCE>
                <UNCERTSEMIMAJOR>2000000</UNCERTSEMIMAJOR>
                <UNCERTSEMIMINOR>2000000</UNCERTSEMIMINOR>
                <UNCERTALTITUDE>65535</UNCERTALTITUDE>
                <SECTORANTENNA>
                    <element>
                        <CN>0</CN>
                        <SRN>102</SRN>
                        <SN>0</SN>
                        <ANTN>2</ANTN><!--R0C-->
                    </element>
                    <element>
                        <CN>0</CN>
                        <SRN>102</SRN>
                        <SN>0</SN>
                        <ANTN>0</ANTN><!--R0A-->
                    </element>
                </SECTORANTENNA>
            </attributes>
        </SECTOR>'''

SECTOREQM_xml_string = '''<SECTOREQM>
			<attributes>
				<SECTOREQMID>20</SECTOREQMID>
				<SECTORID>20</SECTORID>
				<SECTOREQMANTENNA>
					<element>
						<CN>0</CN>
						<SRN>102</SRN>
						<SN>0</SN>
						<ANTN>2</ANTN>
						<ANTTYPE>3</ANTTYPE>
						<TXBKPMODE>0</TXBKPMODE>
					</element>
					<element>
						<CN>0</CN>
						<SRN>102</SRN>
						<SN>0</SN>
						<ANTN>0</ANTN>
						<ANTTYPE>3</ANTTYPE>
						<TXBKPMODE>0</TXBKPMODE>
					</element>
				</SECTOREQMANTENNA>
				<ANTCFGMODE>0</ANTCFGMODE>
				<RRUCN>4294967295</RRUCN>
				<RRUSRN>4294967295</RRUSRN>
				<RRUSN>4294967295</RRUSN>
				<BEAMSHAPE>255</BEAMSHAPE>
				<BEAMLAYERSPLIT>255</BEAMLAYERSPLIT>
				<BEAMAZIMUTHOFFSET>255</BEAMAZIMUTHOFFSET>
			</attributes>
		</SECTOREQM>'''


RRUCHAIN_xml_string = '''<RRUCHAIN>
			<attributes>
				<RCN>2</RCN>
				<TT>0</TT>
				<BM>0</BM>
				<HCN>0</HCN>
				<HSRN>1</HSRN>
				<HSN>4</HSN>
				<HPN>2</HPN>
				<BRKPOS1>255</BRKPOS1>
				<BRKPOS2>255</BRKPOS2>
				<AT>0</AT>
				<CR>255</CR>
				<LSN>255</LSN>
				<PROTOCOL>254</PROTOCOL>
				<SBT>6</SBT>
				<CONNPORTNUM>0</CONNPORTNUM>
				<USERDEFRATENEGOSW>0</USERDEFRATENEGOSW>
				<BITRATESET>127</BITRATESET>
				<RATECHGPERIOD>1</RATECHGPERIOD>
				<RESVBW>255</RESVBW>
				<LCN>255</LCN>
				<LSRN>255</LSRN>
				<HSPN>0</HSPN>
			</attributes>
		</RRUCHAIN>'''

ALMPORT_xml_string = '''<ALMPORT>
		<attributes>
			<CN>0</CN>
			<SRN>102</SRN>
			<SN>0</SN>
			<PN>3</PN>
			<SW>0</SW><!--OFF-->
			<AID>65033</AID>
			<PT>0</PT><!--Digital Port-->
			<AVOL>1</AVOL><!--Low Voltage-->
			<DTPRD>255</DTPRD><!--System default value-->
			<USERLABEL></USERLABEL>
		</attributes>
	</ALMPORT>'''

ANTENNAPORT_xml_string = '''<ANTENNAPORT>
		<attributes>
			<CN>0</CN>
			<SRN>101</SRN>
			<SN>0</SN>
			<PN>3</PN><!--R0D-->
			<FEEDERLENGTH>0</FEEDERLENGTH>
			<DLDELAY>100</DLDELAY>
			<ULDELAY>100</ULDELAY>
			<PWRSWITCH>1</PWRSWITCH><!--OFF-->
			<THRESHOLDTYPE>0</THRESHOLDTYPE><!--USER_DEFINED-->
			<UOTHD>40</UOTHD>
			<UCTHD>60</UCTHD>
			<OOTHD>185</OOTHD>
			<OCTHD>155</OCTHD>
			<ULTRADELAYSW>0</ULTRADELAYSW><!--OFF-->
		</attributes>
	</ANTENNAPORT>'''

RETPORT_xml_string = '''<RETPORT>
		<attributes>
			<CN>0</CN>
			<SRN>62</SRN>
			<SN>0</SN>
			<PN>2</PN><!--RET_PORT-->
			<PWRSWITCH>0</PWRSWITCH><!--ON-->
			<THRESHOLDTYPE>4</THRESHOLDTYPE><!--RET_ONLY_MULTICORE-->
			<UOTHD>10</UOTHD>
			<UCTHD>15</UCTHD>
			<OOTHD>150</OOTHD>
			<OCTHD>120</OCTHD>
		</attributes>
	</RETPORT>'''

TXBRANCH_xml_string = '''<TXBRANCH>
		<attributes>
			<CN>0</CN>
			<SRN>102</SRN>
			<SN>0</SN>
			<TXNO>3</TXNO>
			<TXSW>0</TXSW><!--ON-->
		</attributes>
	</TXBRANCH>'''

RXBRANCH_xml_string = '''<RXBRANCH>
		<attributes>
			<CN>0</CN>
			<SRN>102</SRN>
			<SN>0</SN>
			<RXNO>1</RXNO>
			<RXSW>0</RXSW><!--ON-->
			<ATTEN>0</ATTEN>
			<RTWPINITADJ0>0</RTWPINITADJ0>
			<RTWPINITADJ1>0</RTWPINITADJ1>
			<RTWPINITADJ2>0</RTWPINITADJ2>
			<RTWPINITADJ3>0</RTWPINITADJ3>
			<RTWPINITADJ4>0</RTWPINITADJ4>
			<RTWPINITADJ5>0</RTWPINITADJ5>
			<RTWPINITADJ6>0</RTWPINITADJ6>
			<RTWPINITADJ7>0</RTWPINITADJ7>
		</attributes>
	</RXBRANCH>'''
CPRIPORT_xml_string = '''<CPRIPORT>
		<attributes>
			<CN>0</CN>
			<SRN>101</SRN>
			<SN>0</SN>
			<OPTN>0</OPTN>
			<ADMINISTRATIVESTATE>1</ADMINISTRATIVESTATE>
			<PT>8</PT>
			<SPN>255</SPN>
			<SFPSW>1</SFPSW>
		</attributes>
	</CPRIPORT>'''
SFP_xml_string = '''<SFP>
		<attributes>
			<CN>0</CN>
			<SRN>100</SRN>
			<SN>0</SN>
			<MODULEID>1</MODULEID>
			<PT>8</PT>
		</attributes>
	</SFP>'''
RET_xml_string = '''<RET>
     <attributes>
      <DEVICENO>8</DEVICENO>
      <RETTYPE>1</RETTYPE>
      <POLARTYPE>2</POLARTYPE>
      <SCENARIO>1</SCENARIO>
      <SUBUNITNUM>1</SUBUNITNUM>
      <ANTENNAFORM>0</ANTENNAFORM>
      <DEVICENAME>OXLE21S8</DEVICENAME>
      <CTRLCN>0</CTRLCN>
      <CTRLSRN>68</CTRLSRN>
      <CTRLSN>0</CTRLSN>
      <VENDORCODE>KA</VENDORCODE>
      <SERIALNO>E4L2755862C-Y1</SERIALNO>
     </attributes>
    </RET>'''
RETSUBUNIT_xml_string = '''<RETSUBUNIT>
     <attributes>
      <DEVICENO>8</DEVICENO>
      <SUBUNITNO>1</SUBUNITNO>
      <CONNCN1>0</CONNCN1>
      <CONNSRN1>68</CONNSRN1>
      <CONNSN1>0</CONNSN1>
      <CONNPN1>0</CONNPN1>
      <CONNCN2>255</CONNCN2>
      <CONNPN2>1</CONNPN2>
      <TILT>60</TILT>
      <AER>5</AER>
      <SUBNAME>OXLE21I</SUBNAME>
     </attributes>
    </RETSUBUNIT>'''

NODE_xml_string = '''<NODE>
		<attributes>
			<PRODUCTTYPE>8</PRODUCTTYPE>
			<USERLABEL />
			<NERMVERSION>5900HERTBBUV500R009C10SPC210</NERMVERSION>
			<NODEID>1</NODEID>
			<NODENAME>BXL1J2</NODENAME>
			<WM>1</WM>
			<SWVERSION>BTS3900_5900 V100R015C10SPC210</SWVERSION>
			<HOTPATCHVERSION>BTS3900_5900 V100R015C10SPH213</HOTPATCHVERSION>
			<PRODUCTVERSION>BTS5900 V100R015C10SPC210</PRODUCTVERSION>
			<INTERFACEID>BTS5900 LTE V100R015C10SPC210</INTERFACEID>
			<LMTVERSION>BTS5900 LTE V100R015C10SPC210</LMTVERSION>
			<APPVERSION>V500R009C10SPC210</APPVERSION>
			<APPHOTPATCHVERSION>V500R009C10SPH213</APPHOTPATCHVERSION>
			<LTEMODE>0</LTEMODE>
		</attributes>
	</NODE>'''

NE_xml_string = '''<NE>
 <attributes>
  <LOCATION>OXLE21</LOCATION>
  <SWVERSION>BTS3900_5900 V100R015C10SPC210</SWVERSION>
  <NERMVERSION>3900LTEDATAV100R015C10SPC210</NERMVERSION>
  <INTERFACEID>BTS3900 LTE V100R015C10SPC210</INTERFACEID>
  <PRODUCTVERSION>BTS3900 V100R015C10SPC210</PRODUCTVERSION>
  <LMTVERSION>BTS3900 LTE V100R015C10SPC210</LMTVERSION>
  <DID>AUTODID_20150303_055829b0-c1c1-11e4-8000-0021287e6</DID>
  <SITENAME>O2873</SITENAME>
  <NENAME>OXLE21</NENAME>
  <HOTPATCHVERSION>BTS3900_5900 V100R015C10SPH213</HOTPATCHVERSION>
  <CLOUDBBID>0</CLOUDBBID>
 </attributes>
</NE>'''


[print(key) for key in globals().keys() if 'xml' in key]
