from source.parseMO import Mo
from source.templatefunctionsMO import rmv_old_mo_iterateback, \
    rmv_old_mo_iterateback_valueislist


class Ret(Mo):

    def rmv_retsubunit_only(self, deviceno):
        rmv_old_mo_iterateback(self.root, 'RETSUBUNIT', 'DEVICENO', deviceno)
        self.tree.write(self.output)

    def rmv_ret_only(self, srn):
        """Will remove LTE 2100 RET, also RETSUBUNIT, RETDEVICEDATA.
           Other RET removal is done with RRU remove function.
        """
        List_devno_srn = []
        for child0 in self.root:
            for child1 in child0:
                for child2 in child1[::-1]:
                    if child2.tag == 'RET':
                        for child3 in child2:
                            list_devno_srn = []
                            for child4 in child3:
                                if child4.tag == 'DEVICENO':
                                    list_devno_srn.append(str(child4.text))
                                if child4.tag == 'CTRLSRN':
                                    list_devno_srn.append(str(child4.text))
                            List_devno_srn.append(list_devno_srn)
        # print('RETDEVICEDATA and RET CTRLSRN',List_devno_srn)

        Device_no_list_2100 = [List_devno_srn[i][0] for i in
                               range(0, len(List_devno_srn)) if
                               List_devno_srn[i][1] in ['100', '101', '102','4']]
        # print(Device_no_list_2100)

        rmv_old_mo_iterateback(self.root, 'RET', 'CTRLSRN', srn)
        rmv_old_mo_iterateback(self.root, 'RETSUBUNIT', 'CONNSRN1', srn)
        rmv_old_mo_iterateback_valueislist(self.root, 'RETDEVICEDATA', 'DEVICENO', Device_no_list_2100)

        self.tree.write(self.output)


if __name__ == "__main__":
    print("ret.py is being run directly")
else:
    print("ret.py is being imported into another module")



