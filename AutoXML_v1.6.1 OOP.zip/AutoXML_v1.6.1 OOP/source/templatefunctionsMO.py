def rmv_old_mo(root, managed_object, remove_by_element, value):
    """Remove a specific MO based on a template function,
        and fulfilling a parameter-value condition
    """
    for child0 in root:
        for child1 in child0:
            for child2 in child1:
                if child2.tag == managed_object:
                    for child3 in child2:
                        for child4 in child3:
                            if child4.tag == remove_by_element \
                                    and child4.text == str(value):
                                child1.remove(child2)
                                break


def rmv_old_mo_iterateback(root, managed_object, remove_by_element, value):
    """Remove a specific MO based on a template function,
        and fulfilling a parameter-value condition
        with backwards iteration of child1
    """
    for child0 in root:
        for child1 in child0:
            for child2 in child1[::-1]:
                if child2.tag == managed_object:
                    for child3 in child2:
                        for child4 in child3:
                            if child4.tag == remove_by_element \
                                    and child4.text == str(value):
                                child1.remove(child2)

def rmv_old_mo_iterateback_valueislist(root, managed_object, remove_by_element, values):
    """Remove a specific MO based on a template function,
            and fulfilling a parameter-value condition
            with backwards iteration of child1, where value is iterated over a list
        """
    for child0 in root:
        for child1 in child0:
            for child2 in child1[::-1]:
                if child2.tag == managed_object:
                    for child3 in child2:
                        for child4 in child3:
                            if child4.tag == remove_by_element \
                                    and child4.text in values:
                                child1.remove(child2)
                                # ET.dump(child1)

def mod_mo(root, managed_object, modify_by_element, value1, value2):
    """Modify a specific MO by fulfilling a parameter-value condition"""
    for child0 in root:
        for child1 in child0:
            for child2 in child1:
                if child2.tag == '' + managed_object:
                    for child3 in child2:
                        for child4 in child3:
                            if child4.tag == modify_by_element and child4.text == value1:
                                child4.text = value2
                                # break