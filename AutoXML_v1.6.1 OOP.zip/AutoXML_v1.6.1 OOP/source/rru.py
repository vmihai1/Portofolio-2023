import xml.etree.ElementTree as ET
from source.parseMO import Mo
from source.templatefunctionsMO import rmv_old_mo_iterateback,rmv_old_mo_iterateback_valueislist, mod_mo


class Rru(Mo):

    def __init__(self, root, tree, output):
        super().__init__(root, tree, output)
        self.root = root
        self.tree = tree
        self.output = output
        self.almport_list = []

    def insert_rru(self, cn, srn, sn, rruchain, working_mode, rru_type, rxnum, txnum):
        Rru_dict = {
            'CN': str(cn),
            'SRN': str(srn),
            'SN': str(sn),
            'ADMSTATE': str(1),  # BLOCKED~0, UNBLOCKED~1
            'IFFREQ': str(0),  # interference freq 0~6553500, step: 100
            'ALMPROCSW': str(1),
            'CUSTOMEDRFSPECSW': str(2048),
            'ALMPROCTHRHLD': str(30),
            'ALMTHRHLD': str(20),
            'PS': str(0),
            'RCN': str(rruchain),
            'TP': str(0),
            'RS': str(working_mode),
            'RXNUM': str(rxnum),
            'TXNUM': str(txnum),
            'RFTXSIGNDETECTSW': str(0),
            'RFTXSIGNDETECTPERIOD': str(0),
            'RFTXSIGNDETECTTHLD': str(1),
            'RN': str(cn) + '-' + str(srn) + '-' + str(sn),
            'RT': str(rru_type),  # MRRU
            'RFDS': str(0),
            'FMBWH': str(0),
            'LCPSW': str(0),
            'FLAG': str(0),
            'RUSPEC': str(''),
            'RFCONNCN2': str(4294967295),
            'RFCONNSN2': str(4294967295),
            'RFCONNSRN2': str(4294967295),
            'RFCONNTYPE': str(2),
            'TXDUPSW': str(255),
            'DORMANCYSW': str(0),
            'DORMANCYSTARTTIME': str('00:00:00'),
            'DORMANCYSTOPTIME': str('06:00:00'),
            'PAEFFSWITCH': str(0),
            'SCR': str(255),
            'RXHWALMDETECTSW': str(0),
            'RXFREQBANDMUTUALSW': str(0),
            'REMOTEFLAG': str(0),
            'USERLABEL': str(''),
            'RFDCPWROFFALMDETECTSW': str(0),
            'BATTOUTPUNDERVOLTTHLD': str(430),
            'MNTMODE': str(0),
            'ST': str('2000-01-01T00:00:00'),
            'ET': str('2037-12-31T23:59:59'),
            'MMSETREMARK': str(''),
            'LEDSW': str(0),
            'PSGID': str(0),
            'WIFISW': str(1),
            'LOCATIONNAME': str(''),
            'CIRCUITBREAKERVALUE': str(0),
            'CALPORTCONSTATUS': str(0),
            'PIM3CFGSW': str(0)
        }

        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'RRU':
                        subelement0 = ET.SubElement(child1, 'RRU')
                        subelement1 = ET.SubElement(subelement0, 'attributes')
                        for k, v in Rru_dict.items():
                            ET.SubElement(subelement1, k).text = str(v)
                        break

        if rru_type == 15:  # MRRU
            self.almport_list = [0, 1, 2, 3]
        if rru_type == 12303:  # LRRU
            self.almport_list = [0, 1]

        # Almport_dict does not include the almport no item which is given thorugh the initial for loop
        Almport_dict = {
            'CN': str(cn),
            'SRN': str(srn),
            'SN': str(sn),
            'SW': str(0),
            'AID': str(65033),
            'PT': str(0),
            'AVOL': str(1),
            'DTPRD': str(255),
            'USERLABEL': str('')

        }
        for almportno in self.almport_list:
            for child0 in self.root:
                for child1 in child0:
                    for child2 in child1:
                        if child2.tag == '' + 'ALMPORT':
                            subelement0 = ET.SubElement(child1,'ALMPORT')
                            subelement1 = ET.SubElement(subelement0,'attributes')

                            ET.SubElement(subelement1,'PN').text = str(almportno)
                            # Almport_dict does not include the almport no item which is given thorugh the initial for loop
                            for k, v in Almport_dict.items():
                                ET.SubElement(subelement1, k).text = str(v)
                            break
        Antennaport_dict = {
            'CN': str(cn),
            'SRN': str(srn),
            'SN': str(sn),
            'FEEDERLENGTH': str(0),
            'DLDELAY': str(100),
            'ULDELAY': str(100),
            'PWRSWITCH': str(1),
            'THRESHOLDTYPE': str(0),
            'UOTHD': str(40),
            'UCTHD': str(60),
            'OOTHD': str(185),
            'OCTHD': str(155),
            'ULTRADELAYSW': str(0)
        }
        for antennaportnumber in range(0, max(rxnum, txnum)):
            for child0 in self.root:
                for child1 in child0:
                    for child2 in child1:
                        if child2.tag == '' + 'ANTENNAPORT':
                            subelement0 = ET.SubElement(child1,'ANTENNAPORT')
                            subelement1 = ET.SubElement(subelement0, 'attributes')

                            ET.SubElement(subelement1, 'PN').text = str(antennaportnumber)
                            for k, v in Antennaport_dict.items():
                                ET.SubElement(subelement1, k).text = str(v)
                            break

        Report_dict  = {
            'CN': str(cn),
            'SRN': str(srn),
            'SN': str(sn),
            'PN': str(2),  # default RETPORT enum value
            'PWRSWITCH': str(0),  # ON
            'THRESHOLDTYPE': str(4),  # RET_ONLY_MULTICORE
            'UOTHD': str(10),
            'UCTHD': str(15),
            'OOTHD': str(150),
            'OCTHD': str(120)
        }
        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'RETPORT':
                        subelement0 = ET.SubElement(child1, 'RETPORT')
                        subelement1 = ET.SubElement(subelement0, 'attributes')
                        for k, v in Report_dict.items():
                            ET.SubElement(subelement1, k).text = str(v)
                        break

        Txbranch_dict = {
            'CN': str(cn),
            'SRN': str(srn),
            'SN': str(sn),
            'TXSW': str(0)  # ON

        }
        for txbranchno in range(0, txnum):
            for child0 in self.root:
                for child1 in child0:
                    for child2 in child1:
                        if child2.tag == '' + 'TXBRANCH':
                            subelement0 = ET.SubElement(child1,'TXBRANCH')
                            subelement1 = ET.SubElement(subelement0, 'attributes')
                            for k, v in Txbranch_dict.items():
                                ET.SubElement(subelement1, k).text = str(v)

                            ET.SubElement(subelement1, 'TXNO').text = str(txbranchno)
                            break

        Rxbranch_dict = {
            'CN': str(cn),
            'SRN': str(srn),
            'SN': str(sn),
            'RXSW': str(0),  # ON
            'ATTEN': str(0),
            'RTWPINITADJ0': str(0),
            'RTWPINITADJ1': str(0),
            'RTWPINITADJ2': str(0),
            'RTWPINITADJ3': str(0),
            'RTWPINITADJ4': str(0),
            'RTWPINITADJ5': str(0),
            'RTWPINITADJ6': str(0),
            'RTWPINITADJ7': str(0)

        }
        for rxbranchno in range(0, rxnum):
            for child0 in self.root:
                for child1 in child0:
                    for child2 in child1:
                        if child2.tag == '' + 'RXBRANCH':
                            subelement0 = ET.SubElement(child1,'RXBRANCH')
                            subelement1 = ET.SubElement(subelement0, 'attributes')

                            ET.SubElement(subelement1, 'RXNO').text = str(rxbranchno)
                            for k, v in Rxbranch_dict.items():
                                ET.SubElement(subelement1, k).text = str(v)

                            break
        Cpriport_dict = {
            'CN': str(cn),
            'SRN': str(srn),
            'SN': str(sn),
            'ADMINISTRATIVESTATE': str(1),
            'PT': str(8),  # HEI~5, CPRI~8, CPRI_E/CPRI_O~9, XCI~10
            'SPN': str(255),  # error previously: it was 0, changed on 6.11.2020
            'SFPSW': str(1)

        }
        for cpriport in [0, 1]:
            for child0 in self.root:
                for child1 in child0:
                    for child2 in child1:
                        if child2.tag == '' + 'CPRIPORT':
                            subelement0 = ET.SubElement(child1,'CPRIPORT')
                            subelement1 = ET.SubElement(subelement0, 'attributes')
                            ET.SubElement(subelement1, 'OPTN').text = str(cpriport)
                            for k, v in Cpriport_dict.items():
                                ET.SubElement(subelement1, k).text = str(v)
                            break

        Sfp_dict = {
            'CN': str(cn),
            'SRN': str(srn),
            'SN': str(sn),
            'PT': str(8)
        }
        for sfp in [0, 1]:
            for child0 in self.root:
                for child1 in child0:
                    for child2 in child1:
                        if child2.tag == '' + 'SFP':
                            subelement0 = ET.SubElement(child1, 'SFP')
                            subelement1 = ET.SubElement(subelement0,'attributes')
                            ET.SubElement(subelement1,'MODULEID').text = str(sfp)
                            for k, v in Sfp_dict.items():
                                ET.SubElement(subelement1, k).text = str(v)
                            break
        self.tree.write(self.output)

    def rmv_rru(self, srn, ret_id_devicedata):
        self.tma_list_toremove = []
        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'TMA':
                        for child3 in child2:
                            for child4 in child3:
                                if child4.tag == 'DEVICENO' and child4.text not in self.tma_list_toremove:
                                    self.tma_list_toremove.append(str(child4.text))

        rmv_old_mo_iterateback(self.root, 'RRU', 'SRN', srn)
        rmv_old_mo_iterateback(self.root, 'ALMPORT', 'SRN', srn)
        rmv_old_mo_iterateback(self.root, 'ANTENNAPORT', 'SRN', srn)
        rmv_old_mo_iterateback(self.root, 'RETPORT', 'SRN', srn)
        rmv_old_mo_iterateback(self.root, 'TXBRANCH', 'SRN', srn)
        rmv_old_mo_iterateback(self.root, 'RXBRANCH', 'SRN', srn)
        rmv_old_mo_iterateback(self.root, 'CPRIPORT', 'SRN', srn)
        rmv_old_mo_iterateback(self.root, 'SFP', 'SRN', srn)
        rmv_old_mo_iterateback(self.root, 'RET', 'CTRLSRN', srn)
        rmv_old_mo_iterateback(self.root, 'RETSUBUNIT', 'CONNSRN1', srn)
        rmv_old_mo_iterateback(self.root, 'RETDEVICEDATA', 'DEVICENO', ret_id_devicedata)
        rmv_old_mo_iterateback_valueislist(self.root, 'TMA', 'DEVICENO', self.tma_list_toremove)
        rmv_old_mo_iterateback_valueislist(self.root, 'TMASUBUNIT', 'DEVICENO', self.tma_list_toremove)
        rmv_old_mo_iterateback_valueislist(self.root, 'TMADEVICEDATA', 'DEVICENO', self.tma_list_toremove)

        self.tree.write(self.output)

    def mod_rru_onlyrruchainno(self, srn, rcn1, rcn2):
        flag = False
        for child0 in self.root:
            flag = False
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'RRU':
                        for child3 in child2:
                            flag = False
                            for child4 in child3:
                                if child4.tag == 'SRN' and child4.text == str(srn):
                                    flag = True
                                if flag and child4.tag == 'RCN' and child4.text == str(rcn1):
                                    child4.text = str(rcn2)

        self.tree.write(self.output)

    def mod_lrru_to_mrru(self, oldsrn, newsrn, newtxnum, newrxnum,new_wm, newrrutype):
        flag = False
        i = 0
        for child0 in self.root:
            flag = False
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'RRU':
                        for child3 in child2:
                            flag = False
                            for child4 in child3:
                                if child4.tag == 'SRN' and child4.text == str(oldsrn):
                                    child4.text = str(newsrn)
                                    if i < 1:
                                        ET.SubElement(child3, 'IFFREQ').text = str(0)
                                        ET.SubElement(child3, 'LEDSW').text = str(0)
                                        ET.SubElement(child3, 'LCPSW').text = str(0)
                                        ET.SubElement(child3,'DORMANCYSW').text = str(0)
                                        i = 1
                                    flag = True
                                if flag and child4.tag == 'RXNUM':
                                    child4.text = str(newrxnum)
                                if flag and child4.tag == 'TXNUM':
                                    child4.text = str(newtxnum)
                                if flag and child4.tag == 'RT':
                                    child4.text = str(newrrutype)
                                if flag and child4.tag == 'RS':
                                    child4.text = str(new_wm)
        self.tree.write(self.output)

    def mod_rru_subrack(self, oldsrn, newcn, newsrn, newsn, newtxnum, newrxnum, new_wm, newtype):
        """mod_RRU_ALMPORT_ANTENNAPORT_RETPORT_RXB_TXB_CPRIPORT_SFP_args_oldSRN_newCN_newSRN_newSN__newTXNUM_newRXNUM_newWM_newRRUType"""
        flag = False
        for child0 in self.root:
            flag = False
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'RRU':
                        for child3 in child2:
                            flag = False
                            for child4 in child3:
                                if child4.tag == 'SRN' and child4.text == str(oldsrn):
                                    child4.text = str(newsrn)
                                    flag = True
                                if flag and child4.tag == 'RXNUM':
                                    child4.text = str(newrxnum)
                                if flag and child4.tag == 'TXNUM':
                                    child4.text = str(newtxnum)
                                if flag and child4.tag == 'RT':
                                    child4.text = str(newtype)
                                if flag and child4.tag == 'RS':
                                    child4.text = str(new_wm)

        mod_mo(self.root,'ALMPORT','SRN',oldsrn, newsrn)
        mod_mo(self.root, 'RETPORT', 'SRN', oldsrn, newsrn)
        mod_mo(self.root, 'CPRIPORT', 'SRN', oldsrn, newsrn)
        mod_mo(self.root, 'SFP', 'SRN', oldsrn, newsrn)

        Txbranch_dict2 = {
            'CN': str(newcn),
            'SRN': str(newsrn),
            'SN': str(newsn),
            'TXSW': str(0)  # ON

        }

        i = 0
        for child0 in self.root:
            for child1 in child0:
                for child2 in child1[::-1]:
                    if child2.tag == '' + 'TXBRANCH':
                        for child3 in child2:
                            for child4 in child3:
                                if child4.tag == 'SRN' and child4.text == str(oldsrn):
                                    if i < 1:
                                        for item in range(0, newtxnum):
                                            subelement0 = ET.SubElement(child1, 'TXBRANCH')
                                            subelement1 = ET.SubElement(subelement0,'attributes')
                                            for k, v in Txbranch_dict2.items():
                                                ET.SubElement(subelement1, k).text = str(v)
                                            ET.SubElement(subelement1, 'TXNO').text = str(item)
                                            i = 1
                                    child1.remove(child2)
        Rxbranch_dict2 = {
            'CN': str(newcn),
            'SRN': str(newsrn),
            'SN': str(newsn),
            'RXSW': str(0),  # ON
            'ATTEN': str(0),
            'RTWPINITADJ0': str(0),
            'RTWPINITADJ1': str(0),
            'RTWPINITADJ2': str(0),
            'RTWPINITADJ3': str(0),
            'RTWPINITADJ4': str(0),
            'RTWPINITADJ5': str(0),
            'RTWPINITADJ6': str(0),
            'RTWPINITADJ7': str(0)

        }
        i = 0
        for child0 in self.root:
            for child1 in child0:
                for child2 in child1[::-1]:
                    if child2.tag == '' + 'RXBRANCH':
                        for child3 in child2:
                            for child4 in child3:
                                if child4.tag == 'SRN' and child4.text == str(oldsrn):
                                    if i < 1:
                                        for item in range(0, newrxnum):
                                            subelement0 = ET.SubElement(child1, 'RXBRANCH')
                                            subelement1 = ET.SubElement(subelement0,'attributes')
                                            for k, v in Rxbranch_dict2.items():
                                                ET.SubElement(subelement1, k).text = str(v)
                                            ET.SubElement(subelement1, 'RXNO').text = str(item)
                                            i = 1
                                    child1.remove(child2)

        Antennaport_dict2 = {
            'CN': str(newcn),
            'SRN': str(newsrn),
            'SN': str(newsn),
            'FEEDERLENGTH': str(0),
            'DLDELAY': str(100),
            'ULDELAY': str(100),
            'PWRSWITCH': str(1),
            'THRESHOLDTYPE': str(0),
            'UOTHD': str(40),
            'UCTHD': str(60),
            'OOTHD': str(185),
            'OCTHD': str(155),
            'ULTRADELAYSW': str(0)
        }
        i = 0
        for child0 in self.root:
            for child1 in child0:
                for child2 in child1[::-1]:
                    if child2.tag == '' + 'ANTENNAPORT':
                        for child3 in child2:
                            for child4 in child3:
                                if child4.tag == 'SRN' and child4.text == str(oldsrn):
                                    if i < 1:
                                        for item in range(0, max(newtxnum, newrxnum)):
                                            subelement0 = ET.SubElement(child1, 'ANTENNAPORT')
                                            subelement1 = ET.SubElement(subelement0,'attributes')
                                            for k, v in Antennaport_dict2.items():
                                                ET.SubElement(subelement1, k).text = str(v)
                                            ET.SubElement(subelement1, 'PN').text = str(item)
                                            i = 1
                                    child1.remove(child2)

        mod_mo(self.root,'RET','CTRLSRN',oldsrn,newsrn)
        mod_mo(self.root, 'RETSUBUNIT', 'CONNSRN1', oldsrn, newsrn)
        mod_mo(self.root, 'TMA', 'CTRLSRN', oldsrn, newsrn)
        mod_mo(self.root, 'TMASUBUNIT', 'CTRLSRN', oldsrn, newsrn)

        self.tree.write(self.output)


if __name__ == "__main__":
    print("rru.py  run directly")
else:
    print("rru.py  imported into main")