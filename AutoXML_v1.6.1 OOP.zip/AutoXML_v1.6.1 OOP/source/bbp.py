import xml.etree.ElementTree as ET
from source.parseMO import Mo
from source.templatefunctionsMO import rmv_old_mo
from source.templatefunctionsMO import rmv_old_mo_iterateback
from source.templatefunctionsMO import mod_mo


class Bbp(Mo):

    def insert_bbp_only(self,cn, srn,sn, bbptype, bbws):
        """To be used  if needed to add  BBP board only,
            without SFP, CPRIPORT, CASCADEPORT
        """
        Bbp_dict = {
            'CN': cn,
            'SRN': srn,
            'SN': sn,
            'TYPE': bbptype, # UBBP~2, UBBP-W~181, GBBP~4098, WBBP~8194, LBBP~12290, LPMP~12546, LCOP~12802.text = str(TYPE)
            'OVERLOADALMRPTTHLD': '90',
            'OVERLOADALMCLRTHLD': '85',
            'ADMSTATE': '1',
            'TIME': '0',
            'BLKTP': '0',
            'HCE': '255',
            'CPRIEX': '0',
            'BRDSPEC': '',
            'CCNE': '1',
            'BBWS': bbws, # <BBWS>20</BBWS><!-- GSM:NO;UMTS:NO;LTE FDD:YES;LTE TDD:NO;NB-IoT:YES;NR:NO --> ltefdd=4/ltefdd+iot=20.text = str(BBWS)
            'SRT': '0',
            'CPRIEXMODE': '0',
            'CPRIITFTYPE': '0',
            'CELLDEPLOY': '2',  # SRAN17.1 addition into BBP.text = str(2)
            'EXFUNCSW': '0',  # SRAN17.1 addition into BBP.text = str(0)
            'LTEFLEXSPECSW': 0,
            'WM': '14'  # SRAN16 addition
        }
        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'BBP':
                        subelement0 = ET.SubElement(child1, 'BBP')
                        subelement1 = ET.SubElement(subelement0,'attributes')
                        for k, v in Bbp_dict.items():
                            ET.SubElement(subelement1, k).text = str(v)
                        break
        self.tree.write(self.output)

    def insert_bbp_and_children_mo(self, cn, srn, sn, bbptype, bbws):   # legacy insert_new_BBP_CN_SRN_SN_TYPE_BBWS
        """Create BBP and children MO for
            cn, srn, sn, type and bbws.
        """
        CascadePort_dict = {
            'CN': cn,
            'SRN': srn,
            'SN': sn,
            'PN': '6',
            'PT': '1',
            'SW': '0',
            'PM': '3'
        }
        self.insert_bbp_only(cn, srn, sn, bbptype, bbws)   # call the insert BBP only method.

        for cpriport in range(0, 6):  # continue with children MOs, used range instead of list
            CpriPort_dic = {
                'CN': cn,
                'SRN': srn,
                'SN': sn,
                'OPTN': cpriport,
                'ADMINISTRATIVESTATE': '1',
                'PT': '8',
                'SPN': '0',
                'SFPSW': '1'
            }
            for child0 in self.root:
                for child1 in child0:
                    for child2 in child1:
                        if child2.tag == '' + 'CPRIPORT':
                            subelement0 = ET.SubElement(child1,'CPRIPORT')
                            subelement1 = ET.SubElement(subelement0, 'attributes')
                            for k, v in CpriPort_dic.items():
                                ET.SubElement(subelement1, k).text = str(v)
                            break

        for sfp in range(0, 6):
            Sfp_dict = {
                'CN': cn,
                'SRN': srn,
                'SN': sn,
                'MODULEID': sfp,
                'PT': '8'
            }
            for child0 in self.root:
                for child1 in child0:
                    for child2 in child1:
                        if child2.tag == '' + 'SFP':
                            subelement0 = ET.SubElement(child1, 'SFP')
                            subelement1 = ET.SubElement(subelement0,'attributes')
                            for k, v in Sfp_dict.items():
                                ET.SubElement(subelement1, k).text = str(v)
                            break

        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'CASCADEPORT':
                        subelement0 = ET.SubElement(child1,'CASCADEPORT')
                        subelement1 = ET.SubElement(subelement0, 'attributes')
                        for k, v in CascadePort_dict.items():
                            ET.SubElement(subelement1, k).text = str(v)
                        break
        self.tree.write(self.output)

    def rmv_bbp_and_children_mo(self, sn):
        """Remove BBP and children MO from slot sn."""
        rmv_old_mo(self.root, 'BBP', 'SN', sn)
        rmv_old_mo_iterateback(self.root, 'CPRIPORT', 'SN', sn)
        rmv_old_mo_iterateback(self.root, 'SFP', 'SN', sn)
        rmv_old_mo(self.root, 'CASCADEPORT', 'SN', sn)

        self.tree.write(self.output)

    def mod_bbp_type_slot2slot(self, sn_old, sn_new, bbptype_old, bbptype_new):
        """Change BBP slot and type."""
        varx = 0
        flag = False
        BBP_temp_dict = {
            'LTEFLEXSPECSW': '0',
            'CCNE': '1',
            'BBWS': '4',
            'SRT': '0',
            'CPRIITFTYPE': '0'
        }
        for child0 in self.root:
            flag = False
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'BBP':
                        for child3 in child2:
                            flag = False
                            for child4 in child3:
                                if child4.tag == 'SN' and child4.text == str(sn_old):
                                    flag = True
                                if flag and child4.tag == 'TYPE' \
                                        and child4.text == str(12290):
                                    varx = 1
        i = 0
        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'BBP':
                        for child3 in child2:
                            for child4 in child3:
                                if child4.tag == 'SN' and child4.text == str(sn_old):
                                    child4.text = str(sn_new)
                                    if i < 1 and varx == 1:
                                        for k, v in BBP_temp_dict.items():
                                            ET.SubElement(child3, k).text = str(v)
                                        i = 1
                                if child4.tag == 'TYPE' and child4.text == str(bbptype_old):
                                    child4.text = str(bbptype_new)
                                if child4.tag == 'WM':  # SRAN16.1 V1.1 bug fix
                                    child4.text = str(14)
                                    break
        self.tree.write(self.output)

    def mod_bbp_wbbp2ubbp(self,sn1, sn2, bbptype_old, bbptype_new):
        """Not created , no 3G."""
        pass

    def mod_bbp_slot_type_bbws(self, sn_old, sn_new, bbptype_old, bbptype_new, bbws_old, bbwsnew):
        """Modify BBP by arguments
            sn1, sn2, bbptype1, bbptype2, bbws1, bbws2
        """
        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'BBP':
                        for child3 in child2:
                            for child4 in child3:
                                if child4.tag == 'SN' and child4.text == str(sn_old):
                                    child4.text = str(sn_new)
                                if child4.tag == 'TYPE' and child4.text == str(bbptype_old):
                                    child4.text = str(bbptype_new)
                                if child4.tag == 'BBWS' and child4.text == str(bbws_old):
                                    child4.text = str(bbwsnew)
                                    break

        mod_mo(self.root, 'CPRIPORT', 'SN', sn_old, sn_new)
        mod_mo(self.root, 'SFP', 'SN', sn_old, sn_new)
        mod_mo(self.root, 'CASCADEPORT', 'SN', sn_old, sn_new)

        self.tree.write(self.output)


if __name__ == "__main__":
    print("bbp.py  run directly")
else:
    print("bbp.py  imported into main")