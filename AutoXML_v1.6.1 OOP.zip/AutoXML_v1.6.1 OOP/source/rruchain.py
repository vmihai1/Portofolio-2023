import xml.etree.ElementTree as ET
from source.parseMO import Mo
from source.templatefunctionsMO import rmv_old_mo


class RruChain(Mo):

    def insert_rruchain(self, rruchainno, hcn, hsrn, hsn, hpn):
        Rruchain_dict = {
            'RCN': rruchainno,
            'TT': '0',  # topo type CHAIN~0, RING~1, LOADBALANCE~2, TRUNK_CHAIN~3.text = str(0,
            'BM': '0',  # backup mode /default~0.text = str(0,
            'HCN': hcn,
            'HSRN': hsrn,
            'HSN': hsn,
            'HPN': hpn,
            'BRKPOS1': '255',
            'BRKPOS2': '255',
            'AT': '0',
            'CR': '255',
            'LSN': '255',
            'PROTOCOL': '254',
            'SBT': '6',
            'CONNPORTNUM': '0',
            'USERDEFRATENEGOSW': '0',
            'BITRATESET': '127',
            'RATECHGPERIOD': '1',
            'RESVBW': '255',
            'LCN': '255',
            'LSRN': '255',
            'HSPN': '0'
        }
        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'RRUCHAIN':
                        subelement0 = ET.SubElement(child1, 'RRUCHAIN')
                        subelement1 = ET.SubElement(subelement0, 'attributes')
                        for k, v in Rruchain_dict.items():
                            ET.SubElement(subelement1, k).text = str(v)
                        break
        self.tree.write(self.output)

    def rmv_all_rruchain_from_slotno(self, hsn):
        rmv_old_mo(self.root, 'RRUCHAIN', 'HSN', str(hsn))
        self.tree.write(self.output)

    def rmv_rruchain_by_slot_portno(self, hsn, hpn):
        for child0 in self.root:
            for child1 in child0:
                for child2 in child1[::1]:
                    if child2.tag == 'RRUCHAIN':
                        for child3 in child2:
                            for item in range(0, len(child3)):
                                if (child3[item].tag == 'HSN' and
                                    child3[item].text == str(hsn)) \
                                        and (child3[item + 1].tag == 'HPN'
                                             and child3[item + 1].text == str(hpn)):
                                    child1.remove(child2)
                                    # ET.dump(child1)
                                    break
        self.tree.write(self.output)

    def rmv_rruchain_by_chainid(self, chainid):
        rmv_old_mo(self.root, 'RRUCHAIN', 'RCN', str(chainid))
        self.tree.write(self.output)

    def mod_rruchain_chainno_old2new_hsn(self, chaino, hsn_old, hsn_new):
        flag = False
        for child0 in self.root:
            flag = False
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'RRUCHAIN':
                        for child3 in child2:
                            flag = False
                            for child4 in child3:
                                if child4.tag == 'RCN' and child4.text == str(chaino):
                                    child4.text = str(chaino)
                                    flag = True
                                if flag and child4.tag == 'HSN' and child4.text == str(hsn_old):
                                    child4.text = str(hsn_new)
        self.tree.write(self.output)


if __name__ == "__main__":
    print("rruchain.py  run directly")
else:
    print("rruchain.py  imported into main")