import xml.etree.ElementTree as ET
from source.templatefunctionsMO import rmv_old_mo
from source.parseMO import Mo

# Following functions are used as common code replacer inside the class methods.


def insert_sectoreqm_common_code_1(subelement1, sectoreqmid):  # common code block 1
    ET.SubElement(subelement1, 'SECTOREQMID').text = str(sectoreqmid)
    ET.SubElement(subelement1, 'SECTORID').text = str(sectoreqmid)


def insert_sectoreqm_common_code_1_1(subelement1, sectoreqmid, sectorid):
    ET.SubElement(subelement1, 'SECTOREQMID').text = str(sectoreqmid)
    ET.SubElement(subelement1, 'SECTORID').text = str(sectorid)


def insert_sectoreqm_common_code_3(subelement1):    # common code block 3
    ET.SubElement(subelement1, 'ANTCFGMODE').text = str('0')
    ET.SubElement(subelement1, 'RRUCN').text = str('4294967295')
    ET.SubElement(subelement1, 'RRUSRN').text = str('4294967295')
    ET.SubElement(subelement1, 'RRUSN').text = str('4294967295')
    ET.SubElement(subelement1, 'BEAMSHAPE').text = str('255')
    ET.SubElement(subelement1, 'BEAMLAYERSPLIT').text = str('255')
    ET.SubElement(subelement1, 'BEAMAZIMUTHOFFSET').text = str('255')


def insert_sectoreqm_common_code2(subelement3, cn, srn, sn):    # common code block 2
    ET.SubElement(subelement3, 'CN').text = str(cn)
    ET.SubElement(subelement3, 'SRN').text = str(srn)
    ET.SubElement(subelement3, 'SN').text = str(sn)


class SectorEqm(Mo):
    """Instantiate a SectorEqm MO ,
            containing adding, removing, modifying methods.
        """

    def __str__(self):
        return str("Should be a class specific string")

    def insert_sectoreqm(self, sectoreqmid, cn, srn, sn, antenna_port_list):
        """Used to add a new sectoreqm, Always havind the same SectorEqm ID
            equal to the Sector ID. (legacy method)
            Will be enhanced by other methods..
        """
        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'SECTOREQM':
                        subelement0 = ET.SubElement(child1, 'SECTOREQM')
                        subelement1 = ET.SubElement(subelement0,'attributes')
                        insert_sectoreqm_common_code_1(subelement1,sectoreqmid)  # common code block 1
                        subelement2 = ET.SubElement(subelement1,'SECTOREQMANTENNA')
                        for item in antenna_port_list:
                            subelement3 = ET.SubElement(subelement2, 'element')
                            insert_sectoreqm_common_code2(subelement3, cn, srn,sn)  # common code block 2
                            ET.SubElement(subelement3, 'ANTN').text = str(item)
                            ET.SubElement(subelement3, 'ANTTYPE').text = str('3')
                            ET.SubElement(subelement3, 'TXBKPMODE').text = str('0')
                        insert_sectoreqm_common_code_3(subelement1)  # common code block 3
                        break

        self.tree.write(self.output)

    def insert_superior_sectoreqm(self, sectoreqmid, cn, srn, sn, antenna_port_list):
        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'SECTOREQM':
                        subelement0 = ET.SubElement(child1, 'SECTOREQM')
                        subelement1 = ET.SubElement(subelement0, 'attributes')
                        insert_sectoreqm_common_code_1(subelement1,sectoreqmid)  # common code block 1
                        subelement2 = ET.SubElement(subelement1,'SECTOREQMANTENNA')
                        for item in antenna_port_list:
                            subelement3 = ET.SubElement(subelement2, 'element')
                            insert_sectoreqm_common_code2(subelement3, cn, srn,sn)  # common code block 2
                            ET.SubElement(subelement3, 'ANTN').text = str(item[0])
                            ET.SubElement(subelement3, 'ANTTYPE').text = str(item[1])
                            if item[1] == 3:
                                ET.SubElement(subelement3, 'TXBKPMODE').text = str('0')
                            else:
                                pass
                        insert_sectoreqm_common_code_3(subelement1)  # common code block 3
                        break

        self.tree.write(self.output)

    def insert_multi_sectoreqm(self, sectoreqmid, sectorid, cn, srn, sn, antenna_port_list):
        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'SECTOREQM':
                        subelement0 = ET.SubElement(child1, 'SECTOREQM')
                        subelement1 = ET.SubElement(subelement0, 'attributes')
                        insert_sectoreqm_common_code_1_1(subelement1,sectoreqmid, sectorid)  # common code block 1_1
                        subelement2 = ET.SubElement(subelement1, 'SECTOREQMANTENNA')
                        for item in antenna_port_list:
                            subelement3 = ET.SubElement(subelement2, 'element')
                            insert_sectoreqm_common_code2(subelement3, cn, srn,sn)   # common code block 2
                            ET.SubElement(subelement3, 'ANTN').text = str(item)
                            ET.SubElement(subelement3, 'ANTTYPE').text = str('3')
                            ET.SubElement(subelement3, 'TXBKPMODE').text = str('0')
                        insert_sectoreqm_common_code_3(subelement1)  # common code block 3
                        break

        self.tree.write(self.output)

    def insert_superior_multi_sectoreqm(self, sectoreqmid, sectorid, cn, srn, sn, antenna_port_list):
        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'SECTOREQM':
                        subelement0 = ET.SubElement(child1, 'SECTOREQM')
                        subelement1 = ET.SubElement(subelement0,'attributes')
                        insert_sectoreqm_common_code_1_1(subelement1,sectoreqmid, sectorid)  # common code block 1_1
                        subelement2 = ET.SubElement(subelement1,'SECTOREQMANTENNA')
                        for item in antenna_port_list:
                            subelement3 = ET.SubElement(subelement2, 'element')
                            insert_sectoreqm_common_code2(subelement3, cn, srn,sn)  # common code block 2
                            ET.SubElement(subelement3, 'ANTN').text = str(item[0])
                            ET.SubElement(subelement3, 'ANTTYPE').text = str(item[1])
                            if item[1] == 3:
                                ET.SubElement(subelement3, 'TXBKPMODE').text = str('0')
                            else:
                                pass
                        insert_sectoreqm_common_code_3(subelement1)  # common code block 3
                        break

        self.tree.write(self.output)

    def rmv_sectoreqm(self, sectoreqmid_to_be_removed):
        rmv_old_mo(self.root, 'SECTOREQM', 'SECTOREQMID', sectoreqmid_to_be_removed)
        self.tree.write(self.output)

    def mod_sectoreqm_id(self, id_old, id_new):
        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'SECTOREQM':
                        for child3 in child2:
                            for child4 in child3:
                                if child4.tag == 'SECTOREQMID' and child4.text == str(id_old):
                                    child4.text = str(id_new)
        self.tree.write(self.output)

    def mod_sectoreqm_old_2_new_srn(self,srn_old,cn_new,srn_new,sn_new,antenna_port_list_new):
        i = 0
        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'SECTOREQM':
                        for child3 in child2:
                            for child4 in child3:
                                if child4.tag == 'SECTOREQMANTENNA':
                                    for child5 in child4[::-1]:
                                        for child6 in child5:
                                            if child6.tag == 'SRN' and child6.text == str(srn_old):
                                                if i < 1:
                                                    for item in antenna_port_list_new:
                                                        subelement0 = ET.SubElement(child4, 'element')
                                                        ET.SubElement(subelement0,'ANTN').text = str(item)
                                                        ET.SubElement(subelement0,'ANTTYPE').text = str(3)
                                                        ET.SubElement(subelement0,'CN').text = str(cn_new)
                                                        ET.SubElement(subelement0,'SRN').text = str(srn_new)
                                                        ET.SubElement(subelement0,'SN').text = str(sn_new)
                                                        ET.SubElement(subelement0,'TXBKPMODE').text = str(0)
                                                        i = 1
                                                child4.remove(child5)
                                        # ET.dump(child4)
        self.tree.write(self.output)


if __name__ == "__main__":
    print("sectoreqm.py  run directly")
else:
    print("sectoreqm.py  imported into main")
