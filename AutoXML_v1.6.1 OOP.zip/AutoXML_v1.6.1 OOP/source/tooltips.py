"""https://stackoverflow.com/questions/419163/what-does-if-name-main-do"""
from tkinter import Toplevel, Label


class CreateToolTip:

    """Create a tooltip for a given widget."""

    def __init__(self, widget, text='widget info'):
        self.widget = widget
        self.text = text
        self.widget.bind("<Enter>", self.enter)
        self.widget.bind("<Leave>", self.close)

    def enter(self, event=None):
        #time.sleep(0.5)
        x = y = 0
        x, y, cx, cy = self.widget.bbox("insert")
        x += self.widget.winfo_rootx() + 25
        y += self.widget.winfo_rooty() + 20
        # creates a toplevel window
        self.tw = Toplevel(self.widget)
        # Leaves only the label and removes the app window
        self.tw.wm_overrideredirect(True)
        self.tw.wm_geometry("+%d+%d" % (x, y))
        label = Label(self.tw, text=self.text, justify='left',background='white',
                      relief='solid', borderwidth=0.5,font=("arial", "8", "normal"))
        label.pack(ipadx=1)

    def close(self, event=None):
        if self.tw:
            self.tw.destroy()


if __name__ == "__main__":
    print("tooltips.py is being run directly")
else:
    print("tooltips.py is being imported into another module")

