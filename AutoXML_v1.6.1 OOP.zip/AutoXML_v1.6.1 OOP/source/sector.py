import xml.etree.ElementTree as ET
from source.templatefunctionsMO import rmv_old_mo
from source.parseMO import Mo


def et_subelement(parent, argument: str, parameter_value: str):
    ET.SubElement(parent, argument).text = str(parameter_value)

# import AutoXML_v1_6_bulk_sran17_class


class Sector(Mo):
    """Instantiate a Sector MO ,
        containing adding, removing, modifying methods.
    """

    def insert_sector(self, sectorid, cn, srn, sn, antenna_port_list):
        Sector_dict = {
            'SECTORID': sectorid,
            'SECNAME': 'sector_' + sectorid,
            'LOCATIONNAME': 'sector_' + sectorid,
            'USERLABEL': '% omniFlag::false %',
            'ANTAZIMUTH': '65535',
            'OLDSECTORID': '65535',
            'SECTORIDFORCONVERSION': '65535',
            'SECTORTYPEUMTS': '255',
            'RXANTNUM': '255',
            'DIVMODE': '255',
            'COVERTYPE': '255',
            'RFCONNMODE': '255',
            'SECTORMODELTE': '255',
            'ANTENNAMODE': '255',
            'SECTORCOMBIND': '255',
            'OMNIFLAG': '255',
            'ORIENTOFMAJORAXIS': '255',
            'CONFIDENCE': '255',
            'UNCERTSEMIMAJOR': '2000000',
            'UNCERTSEMIMINOR': '2000000',
            'UNCERTALTITUDE': '65535'
        }
        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'SECTOR':
                        subelement0 = ET.SubElement(child1, 'SECTOR')
                        subelement1 = ET.SubElement(subelement0,'attributes')
                        for k, v in Sector_dict.items():
                            ET.SubElement(subelement1, k).text = str(v)
                        subelement2 = ET.SubElement(subelement1,'SECTORANTENNA')
                        for item in antenna_port_list:
                            subelement3 = ET.SubElement(subelement2, 'element')
                            ET.SubElement(subelement3, 'CN').text = str(cn)
                            ET.SubElement(subelement3, 'SRN').text = str(srn)
                            ET.SubElement(subelement3, 'SN').text = str(sn)
                            ET.SubElement(subelement3, 'ANTN').text = str(item)

                        break
        # self.tree.write(self.OUTPUT,prettyprint=True)
        self.tree.write(self.output)

    def rmv_sector(self, sectorid_to_be_removed):
        rmv_old_mo(self.root, 'SECTOR', 'SECTORID', sectorid_to_be_removed)
        self.tree.write(self.output)

    def mod_sector(self, srn_old, cn_new, srn_new, sn_new, antenna_port_list_new): # cannot modify number of antenna ports, from 2 to 4
        i = 0
        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'SECTOR':
                        for child3 in child2:
                            for child4 in child3:
                                if child4.tag == 'SECTORANTENNA':
                                    for child5 in child4[::-1]:
                                        for child6 in child5:
                                            if child6.tag == 'SRN' and child6.text == str(srn_old):
                                                if i < 1:
                                                    for item in antenna_port_list_new:
                                                        sectorantenna_subelement0 = ET.SubElement(child4,'element')
                                                        ET.SubElement(sectorantenna_subelement0, 'ANTN').text = str(item)
                                                        ET.SubElement(sectorantenna_subelement0, 'CN').text = str(cn_new)
                                                        ET.SubElement(sectorantenna_subelement0, 'SN').text = str(srn_new)
                                                        ET.SubElement(sectorantenna_subelement0, 'SRN').text = str(sn_new)
                                                        i = 1
                                                child4.remove(child5)
                                        # ET.dump(child4)
        self.tree.write(self.output)

    def mod_sector_id(self, id_old, id_new):
        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'SECTOR':
                        for child3 in child2:
                            for child4 in child3:
                                if child4.tag == 'SECTORID' and child4.text == str(id_old):
                                    child4.text = str(id_new)
        self.tree.write(self.output)


print(__name__)

if __name__ == "__main__":
    print("sector.py  run directly")
else:
    print("sector.py  imported into main")
