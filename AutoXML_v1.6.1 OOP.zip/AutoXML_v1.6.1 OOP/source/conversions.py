import xml.etree.ElementTree as ET
from source.parseMO import Mo


class SubrackType(Mo):
    def change_3900_to_5900(self):
        # modify header
        for child0 in self.root:
            if child0.tag == '{1.0.0}fileHeader':
                header_attributes = child0.attrib
                nenrmversion = header_attributes['nenrmversion']
                nenrmversion_5900 = '5900' + str(nenrmversion[4::])
                neversion = header_attributes['neversion']
                neversion_5900 = 'BTS5900' + str(neversion[7::])
                producttype = header_attributes['producttype']
                producttype_5900 = str(8)
        for child0 in self.root:
            if child0.tag == '{1.0.0}fileHeader':
                child0.attrib['nenrmversion'] = nenrmversion_5900
                child0.attrib['neversion'] = neversion_5900
                child0.attrib['producttype'] = producttype_5900

        # add spec_compatibleNrmVersionList as a child of root
        spec_compatibleNrmVersionList = ET.SubElement(self.root,'spec:compatibleNrmVersionList')
        spec_compatibleNrmVersion = ET.SubElement(spec_compatibleNrmVersionList, 'spec:compatibleNrmVersion')
        spec_compatibleNrmVersion.text = nenrmversion_5900

        # modify spec:syndata
        for child0 in self.root:
            if child0.tag == '{1.0.0}syndata':
                if 'HERTBBU' in str(child0.attrib['nermversion']):
                    child0.attrib['nermversion'] = "5900" + child0.attrib['nermversion'][4::]  # "5900HERTBBUV500R009C10SPC210"
                else:
                    child0.attrib['nermversion'] = nenrmversion_5900
                child0.attrib['productversion'] = neversion_5900

        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'SUBRACK':
                        for child3 in child2:
                            for child4 in child3:
                                # print(child4.tag)
                                # BBU3900~128, BBU3910~159, BBU5900~166
                                if child4.tag == 'TYPE' and child4.text == str(159) or child4.tag == 'TYPE' and child4.text == str(128):
                                    child4.text = str(166)
                                    break

        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'NODE':
                        for child3 in child2:
                            for child4 in child3:
                                if child4.tag == 'PRODUCTTYPE' and child4.text == str(1):
                                    child4.text = str(8)
                                if child4.tag == 'PRODUCTVERSION':
                                    child4.text = 'BTS5900' + child4.text[7::]
                                if child4.tag == 'INTERFACEID':
                                    child4.text = 'BTS5900' + child4.text[7::]
                                if child4.tag == 'LMTVERSION':
                                    child4.text = 'BTS5900' + child4.text[7::]
                                if child4.tag == 'NERMVERSION':
                                    child4.text = '5900' + child4.text[4::]
                                    break

        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'NE':
                        for child3 in child2:
                            for child4 in child3:
                                if child4.tag == 'NERMVERSION':
                                    child4.text = '5900' + str(child4.text[4::])
                                if child4.tag == 'INTERFACEID':
                                    child4.text = 'BTS5900' + str(child4.text[7::])
                                if child4.tag == 'PRODUCTVERSION':
                                    child4.text = 'BTS5900' + str(child4.text[7::])
                                if child4.tag == 'LMTVERSION':
                                    child4.text = 'BTS5900' + str(child4.text[7::])
                                    break

        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'eNodeBFunction':
                        for child3 in child2:
                            for child4 in child3:
                                if child4.tag == 'NermVersion':
                                    child4.text = '5900' + child4.text[4::]
                                if child4.tag == 'ProductVersion':
                                    child4.text = 'BTS5900' + child4.text[7::]
                                    break
        self.tree.write(self.output)


class ProductType(Mo):
    def change_5900lte_to_5900(self):
        """For changing product type from 5900 LTE to 5900 / for 5G DSS integration"""
        # modify header
        for child0 in self.root:
            if child0.tag == '{1.0.0}fileHeader':
                header_attributes = child0.attrib
                nenrmversion = header_attributes['nenrmversion']
                nenrmversion_5900_BTS = '5900BTS' + str(nenrmversion[7::])
                neversion = header_attributes['neversion']
                neversion_5900_BTS = 'BTS5900' + str(neversion[7::])
                producttype = header_attributes['producttype']
                producttype_5900 = str(125)
        for child0 in self.root:
            if child0.tag == '{1.0.0}fileHeader':
                child0.attrib['nenrmversion'] = nenrmversion_5900_BTS
                child0.attrib['neversion'] = neversion_5900_BTS
                child0.attrib['producttype'] = producttype_5900

        # add spec_compatibleNrmVersionList as a child of root
        spec_compatibleNrmVersionList = ET.SubElement(self.root,'spec:compatibleNrmVersionList')
        spec_compatibleNrmVersion = ET.SubElement(spec_compatibleNrmVersionList, 'spec:compatibleNrmVersion')
        spec_compatibleNrmVersion.text = nenrmversion_5900_BTS

        """ <NODE> - LTEMode is for BTS3900 LTE, BTS5900 LTE; WMEXTENSION is for BTS5900; they need to have a value in either case, the other can be not specified"""
        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'NODE':
                        for child3 in child2:
                            for child4 in child3:
                                if child4.tag == 'PRODUCTTYPE':
                                    child4.text = str(125)
                                if child4.tag == 'WM' and child4.text == str(1):
                                    child4.text = str(0)
                                if child4.tag == 'INTERFACEID':
                                    child4.text = 'BTS5900' + child4.text[11::]
                                if child4.tag == 'LMTVERSION':
                                    child4.text = 'BTS5900' + child4.text[11::]
                            ET.SubElement(child3,'WMEXTENSION').text = str(1)
                            break

        for child0 in self.root:
            if child0.tag == '{1.0.0}syndata':
                if str(child0.attrib['FunctionType']) == 'NODE':
                    UDP_ping_detect0 = ET.SubElement(child0, 'class')
                    UDP_ping_detect1 = ET.SubElement(UDP_ping_detect0,'UDPPING')
                    UDP_ping_detect2 = ET.SubElement(UDP_ping_detect1,'attributes')
                    ET.SubElement(UDP_ping_detect2,'TIMEOUTTHD').text = str(5000)
                    ET.SubElement(UDP_ping_detect2,'TIMEOUTCNT').text = str(3)
                    ET.SubElement(UDP_ping_detect2, 'DSCP').text = str(48)

        for child0 in self.root:
            if child0.tag == '{1.0.0}syndata':
                if str(child0.attrib['FunctionType']) == 'NODE':
                    SINGLEIPSWITCH0 = ET.SubElement(child0, 'class')
                    SINGLEIPSWITCH1 = ET.SubElement(SINGLEIPSWITCH0,'SINGLEIPSWITCH')
                    SINGLEIPSWITCH2 = ET.SubElement(SINGLEIPSWITCH1,'attributes')
                    ET.SubElement(SINGLEIPSWITCH2,'SINGLEIPSW').text = str(0)

        for child0 in self.root:
            if child0.tag == '{1.0.0}syndata':
                if str(child0.attrib['FunctionType']) == 'NODE':
                    CPSWITCH0 = ET.SubElement(child0, 'class')
                    CPSWITCH1 = ET.SubElement(CPSWITCH0, 'CPSWITCH')
                    CPSWITCH2 = ET.SubElement(CPSWITCH1, 'attributes')
                    ET.SubElement(CPSWITCH2, 'ES').text = str(0)

        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'NE':
                        for child3 in child2:
                            for child4 in child3:
                                if child4.tag == 'NERMVERSION':
                                    child4.text = '5900BTS' + str(child4.text[7::])
                                if child4.tag == 'INTERFACEID':
                                    child4.text = 'BTS5900' + str(child4.text[11::])
                                if child4.tag == 'LMTVERSION':
                                    child4.text = 'BTS5900' + str(child4.text[11::])
                                    break

        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'eNodeBFunction':
                        for child3 in child2:
                            for child4 in child3:
                                if child4.tag == 'NermVersion':
                                    child4.text = '5900' + child4.text[4::]
                                if child4.tag == 'ProductVersion':
                                    child4.text = 'BTS5900' + child4.text[7::]
                                    break
        self.tree.write(self.output)


if __name__ == "__main__":
    print("conversions.py is being run directly")
else:
    print("conversions.py is being imported ")

