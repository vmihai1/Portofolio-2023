"""contains class: Parse_existing_MO_name,function: parse_BBP"""
import itertools


class Mo:
    def __init__(self,root, tree, output):
        self.root = root
        self.tree = tree
        self.output = output


class ParseExistingMoName:
    """Parses a specified MO from the XML file
    and returns a dict with all same MOs and """

    def __init__(self, root, mo):
        self.root = root
        self.mo = mo
        self.mo_list = []
        self.mo_dict = []  # list not dict
        self.mo_dict1 = []  # list not dict

    """def xml_loop(self, child1tag='', child2tag='', child3tag='', child4tag='', child5tag=''):
        # for child0,child1,child2,child3,child4,child5 in itertools.product(self.root,child0,child2,child3,child4,child5):
        for child0 in self.root:  # iterate tags under root
            for child1 in child0:  # iterate objects under root / syndata
                if child1.tag == child1tag:
                    for child2 in child1:  # iterate objects under root / syndata / SECTOR
                        if child2.tag == child2tag:
                            for child3 in child2:
                                if child3.tag == child3tag:
                                    for child4 in child3:
                                        if child4.tag == child4tag:
                                            for child5 in child4:
                                                if child5.tag == child5tag:
                                                    pass"""

    def mo_iterator(self):
        for child0 in self.root:  # iterate tags under root
            for child1 in child0:  # iterate objects under root / syndata
                for child2 in child1:  # iterate objects under root / syndata / SECTOR
                    if child2.tag == '' + str(self.mo):
                        self.mo_dict.clear()
                        for child3 in child2:
                            for child4 in child3:
                                if len(child4) > 0:
                                    self.mo_dict.append(
                                        {child4.tag: child4.text})
                                    # print('------------  WITH CHILDREN')
                                else:
                                    # print({child4.tag: child4.text})
                                    self.mo_dict.append(
                                        {child4.tag: child4.text})
                                for child5 in child4:  # iterate child objects of objects under attributes (ex. under SECTORNANTENNA)
                                    if len(child5) == 0:
                                        # print({child5.tag: child5.text})
                                        self.mo_dict.append(
                                            {child5.tag: child5.text})
                                        # print('------------  NO CHILDREN')
                                    else:
                                        # print({child5.tag: child5.text})
                                        self.mo_dict.append(
                                            {child5.tag: child5.text})
                                        # print('------------  WITH CHILDREN')
                                        for child6 in child5:
                                            # print({child6.tag: child6.text})
                                            self.mo_dict.append(
                                                {child6.tag: child6.text})
                            self.mo_dict1 = self.mo_dict.copy()
                            self.mo_list.append(self.mo_dict1)
        # print(self.MO_list)
        return self.mo_list


class ParseBBP:

    def __init__(self, root):
        self.root = root
        self.BBP_list = []    # recheck, not recommended

    def parse_bbp(self):
        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'BBP':
                        for child3 in child2:
                            for child4 in child3:
                                if child4.tag == 'SN' and child4.text not in self.BBP_list:
                                    self.BBP_list.append(child4.text)
        return self.BBP_list


if __name__ == "__main__":
    print("parseMO.py is being run directly")
else:
    print("parseMO.py is being imported ")
