import datetime as dt


class  UmptEthportSoftware:
    def __init__(self,root):
        self.root = root
        self.string1 = ''
        self.NE = ''
        self.subrack_initial_no = ''
        self.PN_list_unique = []
        self.flag0 = False
        self.flag = False
        self.BBPtoslotstring = ''
        self.BBP_slot_initial_unique = []
        self.MPT = ''


    def get_ethport_no(self):
        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'DEVIP':
                        for child3 in child2:
                            for child4 in child3:
                                if child4.tag == 'PN' and child4.text not in self.PN_list_unique:
                                    self.PN_list_unique.append(child4.text)
                                    # ET.dump(child1)
                                    break
        if '2' in self.PN_list_unique:
            self.PN_list_unique.remove('2')  # for sites where port '2' is found at DEVIP (Greyspot DT sites)
        return self.PN_list_unique

    def get_ethport_devip_portattribute(self):
        for child0 in self.root:
            self.flag0 = False
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'ETHPORT':
                        for child3 in child2:
                            self.flag0 = False
                            for child4 in child3:
                                if child4.tag == 'PN' and child4.text == self.PN_list_unique[0]:
                                    self.flag0 = True
                                if self.flag0 and child4.tag == 'PA':
                                    self.port_devip_attribute = str(child4.text)  # COPPER~0, FIBER~1, AUTO~2, UNCONFIG~255
                                    #ET.dump(child1)
                                    break
        return self.port_devip_attribute

    def get_subrackinitial(self):
        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'MPT':
                        for child3 in child2:
                            for child4 in child3:
                                if child4.tag == 'TYPE':
                                    self.MPT = child4.text
                                    print(self.MPT)
                                    # ET.dump(child1)
                                    # break
                                if child4.tag == 'SRN':
                                    self.subrack_initial_no = child4.text
                                    print(self.subrack_initial_no)
        return (self.MPT,self.subrack_initial_no)

    def get_NE(self):
        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'NE':
                        for child3 in child2:
                            for child4 in child3:
                                if child4.tag == 'LOCATION' or child4.tag=='NENAME':
                                    self.NE = child4.text
                                    # ET.dump(child1)
                                    break
        return self.NE

    def get_BTSversion_SWversion(self):
        for child0 in self.root:
            if child0.tag == '{1.0.0}fileHeader':
                # print(child0.attrib)
                header_attributes = child0.attrib
                self.neversion = header_attributes['neversion']
                break
        return self.neversion

    def get_bbu_type(self):
        for child0 in self.root:
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'SUBRACK':
                        for child3 in child2:
                            for child4 in child3:
                                if child4.tag == 'TYPE':
                                    self.bbu_type = child4.text
                                    break
        if self.bbu_type == '166':
            self.bbu_type = 'BBU5900  '  ## BBU3900~128, BBU3910~159, BBU5900~166
        elif self.bbu_type == '128':
            self.bbu_type = 'BBU3900  '
        elif self.bbu_type == '159':
            self.bbu_type = 'BBU3910  '
        return self.bbu_type

    def get_BBPtoSlot_mapping(self):
        self.flag = False
        self.BBP_slot_initial_unique = []
        for child0 in self.root:
            self.flag = False
            for child1 in child0:
                for child2 in child1:
                    if child2.tag == '' + 'BBP':
                        for child3 in child2:
                            self.flag = False
                            for child4 in child3:
                                if child4.tag == 'SN':
                                    key = child4.text
                                    self.flag = True
                                if self.flag and child4.tag == 'TYPE':
                                    value = child4.text
                                    dic = {key: value}
                                    if dic not in self.BBP_slot_initial_unique:
                                        self.BBP_slot_initial_unique.append(dic)
                                        # dic.clear()
                                # ET.dump(child1)
        self.BBPtoslotstring = ''
        # UBBP~2, UBBP-W~181, GBBP~4098, WBBP~8194, LBBP~12290, LPMP~12546, LCOP~12802
        for item in self.BBP_slot_initial_unique:
            for k in item.keys():
                if item[k] == '2':
                    self.BBPtoslotstring += ' slot ' + k + ' ' + 'UBBP'
                elif item[k] == '12290':
                    self.BBPtoslotstring += ' slot ' + k + ' ' + 'LBBP'
        return self.BBPtoslotstring


    def get_umpt_ethport_software_string(self):
        # print(BBP_slot_initial_unique)
        self.string1 = str(self.NE) + ':  '
        if self.MPT == '1':
            self.string1 = self.string1 + ' slot 7 UMPT'
        elif self.MPT == '12289':
            self.string1 = self.string1 + ' slot 7 LMPT'
        elif self.MPT == '8193':
            self.string1 = self.string1 + ' slot 7 WMPT'
        self.string1 += '__' + self.BBPtoslotstring + '  ~  '
        if self.PN_list_unique[0] == '1':
            self.string1 = self.string1 + 'Ethport 1'
        elif self.PN_list_unique[0] == '0':
            self.string1 = self.string1 + 'Ethport 0'
        if self.port_devip_attribute == '1':
            self.string1 = self.string1 + ' - ' + '  Fiber'
        elif self.port_devip_attribute == '0':
            self.string1 = self.string1 + ' - ' + '  Copper'
        elif self.port_devip_attribute == '2':
            self.string1 = self.string1 + ' - ' + '  Auto'
        elif self.port_devip_attribute == '255':
            self.string1 = self.string1 + ' - ' + ' Unconfig'
        self.string1 = self.string1 + '  ~  SRN ID  ' + self.subrack_initial_no + '     ' + self.bbu_type + '  ~  ' + self.neversion
        fo = open('LOG.txt', 'a')
        #fo.write(f'{self.dt.datetime.now()} -- {self.NEname} Initial Hardware description: ' + self.string1 + '\n')
        # print(string1)
        fo = open('LOG.txt', 'a')
        fo.write(f'{dt.datetime.now()} -- {self.NE} Initial Hardware description: ' + self.string1 + '\n')
        return self.string1
    @classmethod
    def class_method(cls):
        print("this is a class method")




########################
def UMPT_ETHPORT_SW():
    string1 = ''
    NE = ''
    #Ethport_portID_list_unique=[]
    Interface_portID_list_unique=[]
    subrack_inital_no = ''
    PN_list_unique = []
    for child0 in root:
        for child1 in child0:
            for child2 in child1:
                if child2.tag == '' + 'DEVIP':
                    for child3 in child2:
                        for child4 in child3:
                            if child4.tag == 'PN' and child4.text not in PN_list_unique:
                                PN_list_unique.append(child4.text)
                                #ET.dump(child1)
                                break
                if child2.tag == '' + 'INTERFACE':
                    for child3 in child2:
                        for child4 in child3:
                            if child4.tag == 'PORTID' and child4.text not in Interface_portID_list_unique:
                                Interface_portID_list_unique.append(child4.text)
                                #ET.dump(child1)
                                break

    if '2' in PN_list_unique:
        PN_list_unique.remove('2') # for sites where port '2' is found at DEVIP (Greyspot DT sites)

    if '71' in Interface_portID_list_unique and len(PN_list_unique)==0:
        PN_list_unique.append('1')
    if '70' in Interface_portID_list_unique and len(PN_list_unique)==0:
        PN_list_unique.append('0')
    if '72' in Interface_portID_list_unique and len(PN_list_unique)==0:
        PN_list_unique.append('2')
    if '73' in Interface_portID_list_unique and len(PN_list_unique)==0:
        PN_list_unique.append('3')



    flag0 = False
    for child0 in root:
        flag0 = False
        for child1 in child0:
            for child2 in child1:
                if child2.tag == '' + 'ETHPORT':
                    for child3 in child2:
                        flag0 = False
                        for child4 in child3:
                            if child4.tag == 'PN' and child4.text == PN_list_unique[0]:
                                flag0 = True
                            if flag0 and child4.tag == 'PA':
                                port_devip_attribute = str(child4.text)  # COPPER~0, FIBER~1, AUTO~2, UNCONFIG~255
                                # ET.dump(child1)
                                break
    for child0 in root:
        for child1 in child0:
            for child2 in child1:
                if child2.tag == '' + 'MPT':
                    for child3 in child2:
                        for child4 in child3:
                            if child4.tag == 'TYPE':
                                MPT = child4.text
                                # ET.dump(child1)
                                # break
                            if child4.tag == 'SRN':
                                subrack_inital_no = child4.text
    for child0 in root:
        for child1 in child0:
            for child2 in child1:
                if child2.tag == '' + 'NE':
                    for child3 in child2:
                        for child4 in child3:
                            if child4.tag == 'LOCATION':
                                NE = child4.text
                                # ET.dump(child1)
                                break
    for child0 in root:
        if child0.tag == '{1.0.0}fileHeader':
            # print(child0.attrib)
            header_attributes = child0.attrib
            neversion = header_attributes['neversion']
            break
    for child0 in root:
        for child1 in child0:
            for child2 in child1:
                if child2.tag == '' + 'SUBRACK':
                    for child3 in child2:
                        for child4 in child3:
                            if child4.tag == 'TYPE':
                                bbu_type=child4.text
                                break
    if bbu_type=='166':
        bbu_type='BBU5900  ' ## BBU3900~128, BBU3910~159, BBU5900~166
    elif bbu_type =='128':
        bbu_type = 'BBU3900  '
    elif bbu_type =='159':
        bbu_type = 'BBU3910  '

    flag = False
    BBP_slot_initial_unique = []
    for child0 in root:
        flag = False
        for child1 in child0:
            for child2 in child1:
                if child2.tag == '' + 'BBP':
                    for child3 in child2:
                        flag = False
                        for child4 in child3:
                            if child4.tag == 'SN':
                                key = child4.text
                                flag = True
                            if flag and child4.tag == 'TYPE':
                                value = child4.text
                                dic = {key: value}
                                if dic not in BBP_slot_initial_unique:
                                    BBP_slot_initial_unique.append(dic)
                                    # dic.clear()
                            # ET.dump(child1)
    BBPtoslotstring = ''
    # UBBP~2, UBBP-W~181, GBBP~4098, WBBP~8194, LBBP~12290, LPMP~12546, LCOP~12802
    for item in BBP_slot_initial_unique:
        for k in item.keys():
            if item[k] == '2':
                BBPtoslotstring += ' slot ' + k + ' ' + 'UBBP'
            elif item[k] == '12290':
                BBPtoslotstring += ' slot ' + k + ' ' + 'LBBP'

    # print(BBP_slot_initial_unique)
    string1 = str(NE) + ':  '
    if MPT == '1':
        string1 = string1 + ' slot 7 UMPT'
    elif MPT == '12289':
        string1 = string1 + ' slot 7 LMPT'
    elif MPT == '8193':
        string1 = string1 + ' slot 7 WMPT'
    string1 += '__' + BBPtoslotstring + '  ~  '
    if PN_list_unique[0] == '1':
        string1 = string1 + 'Ethport 1'
    elif PN_list_unique[0] == '0':
        string1 = string1 + 'Ethport 0'
    elif PN_list_unique[0] == '2':
        string1 = string1 + 'Ethport 2'
    elif PN_list_unique[0] == '3':
        string1 = string1 + 'Ethport 3'

    if port_devip_attribute == '1':
        string1 = string1 + ' - ' + '  Fiber'
    elif port_devip_attribute == '0':
        string1 = string1 + ' - ' + '  Copper'
    elif port_devip_attribute == '2':
        string1 = string1 + ' - ' + '  Auto'
    elif port_devip_attribute == '255':
        string1 = string1 + ' - ' + ' Unconfig'
    string1 = string1 + '  ~  SRN ID  ' + subrack_inital_no + '     ' +bbu_type+'  ~  '+ neversion
    fo = open('LOG.txt', 'a')
    fo.write(f'{dt.datetime.now()} -- {NEname} Initial Hardware description: ' + string1 + '\n')
    #print(string1)
    return string1

#not used but to be done
def LMPT_to_UMPT():
    string1 = ''
    PN_list_unique = []
    for child0 in root:
        for child1 in child0:
            for child2 in child1:
                if child2.tag == '' + 'DEVIP':
                    for child3 in child2:
                        for child4 in child3:
                            if child4.tag == 'PN' and child4.text not in PN_list_unique:
                                PN_list_unique.append(child4.text)
                                ET.dump(child1)
                                break
    flag0 = False
    for child0 in root:
        lag0 = False
        for child1 in child0:
            for child2 in child1:
                if child2.tag == '' + 'ETHPORT':
                    for child3 in child2:
                        lag0 = False
                        for child4 in child3:
                            if child4.tag == 'PN' and child4.text == PN_list_unique[0]:
                                flag0 = True
                            if flag0 and child4.tag == 'PA':
                                port_devip_attribute = str(child4.text)  # COPPER~0, FIBER~1, AUTO~2, UNCONFIG~255
                                ET.dump(child1)
                                break
    for child0 in root:
        for child1 in child0:
            for child2 in child1:
                if child2.tag == '' + 'MPT':
                    for child3 in child2:
                        for child4 in child3:
                            if child4.tag == 'TYPE':
                                MPT = child4.text
                                ET.dump(child1)
                                break

    # print('port number', PN_list_unique[0])
    # print('port attribute', port_devip_attribute)
    # print('BOARD TYPE!!!', MPT)
    if MPT == '12289':
        # if PM_list_unique[0]==1 just change in MPT
        # if PM_list_unique[0]==0 change ethport, ipsecbind, MPT
        if (PN_list_unique[0] == '1' and port_devip_attribute == '1') or (
                PN_list_unique[0] == '0' and port_devip_attribute == '0'):
            # UMPT~1, WMPT~8193, LMPT~12289
            for child0 in root:
                for child1 in child0:
                    for child2 in child1:
                        if child2.tag == '' + 'MPT':
                            for child3 in child2:
                                for child4 in child3:
                                    if child4.tag == 'TYPE' and child4.text == '12289':
                                        child4.text = '1'
                                        ET.dump(child1)
                                        break
        if PN_list_unique[0] == '0' and port_devip_attribute == '1':
            for child0 in root:
                for child1 in child0:
                    for child2 in child1:
                        if child2.tag == '' + 'MPT':
                            for child3 in child2:
                                for child4 in child3:
                                    if child4.tag == 'TYPE' and child4.text == '12289':
                                        child4.text = '1'
                                        ET.dump(child1)
                                        break
            for child0 in root:
                for child1 in child0:
                    for child2 in child1:
                        if child2.tag == '' + 'DEVIP':
                            for child3 in child2:
                                for child4 in child3:
                                    if child4.tag == 'PN' and child4.text == '0':
                                        child4.text = '1'
                                        ET.dump(child1)
                                        break
            for child0 in root:
                for child1 in child0:
                    for child2 in child1:
                        if child2.tag == '' + 'IPSECBIND':
                            for child3 in child2:
                                for child4 in child3:
                                    if child4.tag == 'PN' and child4.text == '0':
                                        child4.text = '1'
                                        ET.dump(child1)
                                        break
            # port attribute: COPPER~0, FIBER~1, AUTO~2, UNCONFIG~255
            # SPEED: 10M~0, 100M~1, 1000M~2, AUTO~3, 10G~5, 40G~6, 100G~7, 25G~8, UNCONFIG~255
            # DUPLEX MODE: FULL~1, AUTO~2, UNCONFIG~255

            flag = False
            for child0 in root:
                flag = False
                for child1 in child0:
                    for child2 in child1:
                        if child2.tag == '' + 'ETHPORT':
                            for child3 in child2:
                                flag = False
                                for child4 in child3:
                                    if child4.tag == 'PA' and child4.text == str(
                                            0):
                                        child4.text = str(1)
                                        flag = True
                                    if flag and child4.tag == 'SPEED' and child4.text == str(
                                            3):
                                        child4.text = str(2)
                                    if (flag and child4.tag == 'DUPLEX' and child4.text == str(
                                            2)) or (
                                            flag and child4.tag == 'DUPLEX' and child4.text == str(
                                            255)):
                                        child4.text = str(1)
                                        ET.dump(child1)
                                        break
    tree.write(OUTPUT)



if __name__ == "__main__":
    print("umpt.py is being run directly")
else:
    print("umpt.py is being imported into another module")
