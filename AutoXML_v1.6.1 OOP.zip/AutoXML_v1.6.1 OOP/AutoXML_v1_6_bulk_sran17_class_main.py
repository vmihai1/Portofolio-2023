# external modules
import xml.etree.ElementTree as ET
import datetime as dt
# now = datetime.now().time() # time object
from tkinter import *
from tkinter import filedialog
from source.parseMO import ParseExistingMoName as parser


# my modules
from source.bbp import Bbp

# class for tooltips
# created as ToolTip.py

NEname = ''
# register all  namespaces https://stackoverflow.com/questions/8983041/saving-xml-files-using-elementtree
ET.register_namespace('spec', "1.0.0")
ET.register_namespace('', "http://www.huawei.com/specs/bsc6000_nrm_forSyn_collapse_1.0.0")


# Create the root window
window = Tk()
window.title('       AutoXML V1.6 BULK    \nSRAN17.1')
try:
    window.iconbitmap("happy1.ico")
except:
    window.title('       AutoXML V1.6 BULK    \nSRAN17.1')
# Set window size
window.geometry('{}x{}'.format(1290, 740))
# Set window background color
window.config(background="white")
label_file_explorer1 = Label(window, text="No file selected", width=130, height=1, fg="blue")
label_file_explorer1.grid(column=2, row=1)

fo = open('LOG.txt', 'a')

def browseFiles():
    global root
    global tree
    global OUTPUT
    global fo
    fo = open('LOG.txt', 'a')
    # time.sleep(1)
    filename = filedialog.askopenfilename(initialdir="/C:/", title="Select a File",filetypes=(("XML files", "*.xml*"), ("all files", "*.*")))
    filename2 = filename
    # time.sleep(1)
    fo.write(f'\n{dt.datetime.now()} --  ' + 'Selecting file:  ' + filename2 + '\n')
    # print(filename2)
    # Change label contents
    #label_file_explorer1.configure(text="File Opened: " + filename2)
    text = Text(window, height=1, width=130, font=("arial", 10))
    text.insert(INSERT,"File Opened: " + filename2)
    text.grid(column=2, row=1)
    tree = ET.parse(filename2)
    root = tree.getroot()
    # print(root.text)
    OUTPUT = filename2
    return filename2

OUTPUT = browseFiles()


tree = ET.parse(OUTPUT)
root = tree.getroot()

#intermediary phase -testing classes
# parsed_cell_test_object=ParseExistingMoName(root,"Cell")
# print(parsed_cell_test_object.mo)
# print(parsed_cell_test_object.mo_list)
# print(parsed_cell_test_object.mo_dict)
# print(parsed_cell_test_object.mo_dict1)
# print(parsed_cell_test_object)
# parsed_cell_test_object.mo_iterator()
# print(parsed_cell_test_object.mo)
# print(parsed_cell_test_object.mo_list)
# print(parsed_cell_test_object.mo_dict)
# print(parsed_cell_test_object.mo_dict1)
# print(parsed_cell_test_object)
#

# Umpt_ethport_sw_testobject=UMPT_ETHPORT_SW(root)
# print(Umpt_ethport_sw_testobject.get_ethport_no())
# print(Umpt_ethport_sw_testobject.get_ethport_devip_portattribute())
# print(Umpt_ethport_sw_testobject.get_subrackinitial())
# print(Umpt_ethport_sw_testobject.get_NE())
# print(Umpt_ethport_sw_testobject.get_BTSversion_SWversion())
# print(Umpt_ethport_sw_testobject.get_bbu_type())
# print(Umpt_ethport_sw_testobject.get_BBPtoSlot_mapping())
# print(Umpt_ethport_sw_testobject.get_umpt_ethport_software_string())
# print(Umpt_ethport_sw_testobject.class_method())
#print(UMPT_ETHPORT_SW.class_method())

#
# Sector_testobject=InsertNewSectorIdCnSrnSnAntennaportlist(root,tree,OUTPUT,7000,0,100,0,[0,1,2,3])
# print(Sector_testobject.ANTENNA_PORT_LIST)
# Sector_testobject.insertNewSector()

#
# Sectoreqm_testobject=InsertNewSectorEqmIdCnSrnSnAntennaportlist(root,tree,OUTPUT,7000,0,100,0,[0,1,2,3])
# print(Sectoreqm_testobject)
# Sectoreqm_testobject.insertNewSector()


# Sector1 = Sector(root,tree,OUTPUT)
# Sector1.insert_new_sector(50,0,77,0,[0,1,2,3])
#
#




BBp1=Bbp(root,tree,OUTPUT)
BBp1.insert_bbp_and_children_mo(0,1,2,2,20)




















































































window.mainloop()
