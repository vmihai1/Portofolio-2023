from tkinter import filedialog, ttk
import datetime as dt
from tkinter import *
from AutoXML_v1_6_bulk_sran17_class_main import *


class BrowseFiles:

    def __init__(self, fo):
        self.fo = fo
        self.filename = filedialog.askopenfilename(initialdir="/C:/", title="Select a File",filetypes=(("XML files", "*.xml*"), ("all files", "*.*")))

    def openfile(self):
        filename2 = self.filename
        self.fo.write(f'\n{dt.datetime.now()} --  ' + 'Selecting file:  ' + filename2 + '\n')
        text = Text(window, height=1, width=130, font=("arial", 10))
        text.insert(INSERT, "File Opened: " + filename2)
        text.grid(column=2, row=1)
        tree1 = ET.parse(filename2)
        tree1.getroot()
        return filename2

# def browsefiles():
#     global root
#     global tree
#     global OUTPUT
#     global fo
#     fo = open('LOG.txt', 'a')
#     # time.sleep(1)
#     filename = filedialog.askopenfilename(initialdir="/C:/", title="Select a File",filetypes=(("XML files", "*.xml*"), ("all files", "*.*")))
#     filename2 = filename
#     # time.sleep(1)
#     fo.write(f'\n{dt.datetime.now()} --  ' + 'Selecting file:  ' + filename2 + '\n')
#     text = Text(window, height=1, width=130, font=("arial", 10))
#     text.insert(INSERT,"File Opened: " + filename2)
#     text.grid(column=2, row=1)
#     tree = ET.parse(filename2)
#     root = tree.getroot()
#     OUTPUT = filename2
#
#     return filename2