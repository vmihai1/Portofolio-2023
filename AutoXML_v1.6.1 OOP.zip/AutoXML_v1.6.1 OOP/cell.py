from source.parseMO import Mo, ParseExistingMoName
import datetime as dt

NEName = '' # definem as global for the class
class Cell(Mo):

    def cell_sectoreqm_mapping(self):
        global NEName
        self.list_cell_unique = []
        self.list_sectoreqm_unique = []
        self.string_out = 'Existing Cell:  '
        Cell_ = ParseExistingMoName(self.root, 'Cell')
        Sectoreqm_ = ParseExistingMoName(self.root, 'SECTOREQM')
        X1 = Cell_.mo_iterator()
        X2 = Sectoreqm_.mo_iterator()

        for i in X1:
            for j in i:
                for j in range(0, len(X1)):
                    for item in X1[j]:
                        for key in item.keys():
                            if key == 'CellName':
                                if item[key][1] + '.' + item[key][6] not in self.list_cell_unique:
                                    self.list_cell_unique.append(item[key][1] + '.' + item[key][6])
        for i in X2:
            for j in i:
                for j in range(0, len(X2)):
                    for item in X2[j]:
                        for key in item.keys():
                            if key == 'SECTOREQMID':
                                if item[key] not in self.list_sectoreqm_unique:
                                    self.list_sectoreqm_unique.append(item[key])


        self.list_sectoreqm_unique.sort(key=int)
        self.list_cell_unique.sort()
        for i in range(0, len(self.list_cell_unique)):
            self.string_out += self.list_cell_unique[i] + ',  '
        self.string_out += '\nExisting SectorEqm: '
        for i in range(0, len(self.list_sectoreqm_unique)):
            self.string_out += self.list_sectoreqm_unique[i] + ', '
        # print(string_out)
        fo = open('source/LOG.txt', 'a')
        fo.write(f'{dt.datetime.now()} -- {NEname} Smart Agent lookup: ' + self.string_out + '\n')
        return self.string_out, self.list_cell_unique, self.list_sectoreqm_unique


if __name__ == "__main__":
    print("cell.py is being run directly")
else:
    print("cell.py is being imported ")


###issue with NEname line 43 - how to import it