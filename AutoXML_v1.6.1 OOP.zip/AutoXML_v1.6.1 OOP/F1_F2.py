"""module containing f1,f2 functions"""
def f1():
    """TBD"""
    pass


def f2():
    pass
    """TBD"""

if __name__ == "__main__":
    print("f1.py f2.py is being run directly")
else:
    print("f1.py f2.py is being imported into another module")
print(__name__)