import csv,json,pymongo

def csv_to_json(csv_file_name):  #convert csv to json
    csvfile = open(csv_file_name,'r')
    jsonfile = open('file.json', 'w')

    fieldnames=("Site Name","Cab_type","UL CE","DL CE","Local Cell","HSDPA","HSDPA RRM","HS-PDSCH Code","MBMS","HSUPA")      #csv column headers

    reader = csv.DictReader( csvfile, fieldnames)
    reader_list_format=[ row for row in reader ]
    out = json.dumps( reader_list_format[1::] )
    jsonfile.write(out)
    jsonfile.close()

    json1_file = open('file.json')
    json1_str = json1_file.read()
    json1_data = json.loads(json1_str)
    return json1_data
    # print(json1_str)
    # print(json1_data)

def create_DB_collection(dbName,collectionName,data_to_import):
    myclient = pymongo.MongoClient("mongodb://localhost:27017/")

    # create mongo data base
    mydb = myclient[dbName]
    print(myclient.list_database_names())

    mycollection=mydb[collectionName]
    print(mydb.list_collection_names())

    i=0
    while i<len(data_to_import):
       mycollection.insert_one(data_to_import[i])
       del data_to_import[i]['_id']
       i=i+1

    return mydb,mycollection

def update_DB(myDB,mycol,myquery,mynewvalues):
    #myquery = {"address": "Valley 345"}
    newvalues = {"$set": mynewvalues}
    mycol.update_many(myquery, newvalues)

#main
DATA=csv_to_json("Dresden - Copy.csv")                              #covert csv file to json format
(MYDB,MYCOL)=create_DB_collection("RAN2","RAN2_license_items",DATA)  #import json to DB/collection wanted


myquery_x={"Cab_type": "BTS3900 WCDMA"}
mynewvalues_x={"Cab_type": {"CAB1":"BTS3900","CAB2":"BTS3900","CAB3":"BTS3000","new_CAB":{"1":"Nokia","2":"Ericsson"}}}

update_DB(MYDB,MYCOL,myquery_x,mynewvalues_x)


