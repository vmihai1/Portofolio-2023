def outlook_export(C_saving_folder,Subfolder,my_email_address):
    #wla_Subfolder='wla'
    # should be a folder in C:\
    #C_saving_folder='\\wla\\'
    last_how_many_days = 100 # list is restricted to only today, 00:00:00 by condition
    #my_email_address='valentin.mihai@vodafone.com'

    import win32com.client
    import os
    import time
    import datetime as dt
    #import zipfile

    outlook = win32com.client.Dispatch("Outlook.Application")
    namespace = outlook.GetNamespace("MAPI")
    root_folder=''
    try:
        root_folder1 = namespace.Folders.Item(1) # example:  valentin.mihai@vodafone.com
        root_folder2 = namespace.Folders.Item(2)
        if root_folder1.Name==my_email_address:
            root_folder=root_folder1
        else:
            root_folder=root_folder2
    except:
        pass
    print(f'OUTLOOK Root folder name: {root_folder.Name}')

    subfolder = root_folder.Folders['Inbox'].Folders[Subfolder]
    print(f'OUTLOOK saving folder name: {subfolder.Name}')
    local_folder='C:'+C_saving_folder
    print(f'Local Folder for saved configs {local_folder}')
    messages = subfolder.Items
    messages.Sort("[ReceivedTime]", True)

    # print(messages)
    # print(count_messages)
    # print(dir(messages))


    print(f'Time now: {dt.datetime.now()}')
    today=dt.date.today()
    today_midnight=dt.datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    lastHourDateTime_14 = dt.datetime.now() - dt.timedelta(hours=24*last_how_many_days)
    last2weeksMessages = messages.Restrict("[ReceivedTime] >= '" +lastHourDateTime_14.strftime('%m/%d/%Y %H:%M %p')+"'")
    count_messages=last2weeksMessages.count

    print(f'Time since  receiving WLA logs: {lastHourDateTime_14}')

    #files already existing in the config file

    arr = os.listdir('C:'+C_saving_folder)
    #print(arr)
    daily_folder=str(today)
    if str(today) not in arr:
        daily_folder = os.makedirs('C:\\' + str(C_saving_folder) + str(today))


    if count_messages > 0:
            print(count_messages)
            for i in range(0,count_messages):
                message = messages[i]
                #print(message.ReceivedTime)
                if message.ReceivedTime.replace(tzinfo=None)>=today_midnight.replace(tzinfo=None): # restrict to emails since today 00:00:00

                    #print(str(message.Sender))
                    atch=message.Attachments
                    nbrOfAttachmentInMessage=atch.Count
                    x = 1
                    while x <= nbrOfAttachmentInMessage:

                            attachment = atch.item(x)
                            file_name=str(attachment).split('.')[0]
                            #print(file_name)
                            extension=str(attachment).split('.')[1]
                            #print(extension)
                            #save_path='C:\\'+str(C_saving_folder)+'\\'  + str(file_name)+'_'+str(message.Sender).split(',')[0]+'_'+str(message.Sender).split(',')[1]+'.'+str(extension)

                            #print(daily_folder)
                            if (str(attachment) not in os.listdir('C:'+C_saving_folder+str(today))):
                                #save_path = 'C:' + str(C_saving_folder) + '\\' +daily_folder+ str(file_name) +  '.' + str(extension)
                                save_path='C:' + str(C_saving_folder) + '\\'  + '\\'+ str(file_name) + '.' + str(extension)

                                attachment.SaveAsFile(save_path)

                            x=x+1

#wla_outlook_export(C_saving_folder,wla_Subfolder,my_email_address)
outlook_export('\\1_valentin\\py\\PYTHON PROJECTS\\python\\Mongo_project_1\\','_RET_Data_Transfer','valentin.mihai@vodafone.com')