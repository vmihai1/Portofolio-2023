import pymongo, random
from random import shuffle


my_dict2_TRMMAP={'Common channel primary path':'EF','IMS SRB primary path':'AF42','SRB primary path':'EF',\
                 'AMR voice primary path':'AF43','R99 CS conversational primary path':'AF43',\
                 'R99 CS streaming primary path':'AF41','R99 PS conversational primary path':'AF43',\
                 'R99 PS streaming primary path':'AF41','R99 PS high PRI interactive primary path':'AF41',\
                 'R99 PS middle PRI interactive primary path':'AF31','R99 PS low PRI interactive primary path':'BE',\
                 'R99 PS background primary path':'BE','HSDPA Signal primary path':'EF','HSDPA IMS Signal primary path':'AF42',\
                 'HSDPA Voice primary path':'AF43','HSDPA conversational primary path':'AF43','HSDPA streaming primary path':'AF41',\
                 'HSDPA high PRI interactive primary path':'AF41','HSDPA middle PRI interactive primary path':'AF31',\
                 'HSDPA low PRI interactive primary path':'BE','HSDPA background primary path':'BE','HSUPA Signal primary path':'EF',\
                 'HSUPA IMS Signal primary path':'AF42','HSUPA Voice primary path':'AF43','HSUPA conversational primary path':'AF43',\
                 'HSUPA streaming primary path':'AF41','HSUPA high PRI interactive primary path':'AF41',\
                 'HSUPA middle PRI interactive primary path':'AF31','HSUPA low PRI interactive primary path':'BE',\
                 'HSUPA background primary path':'BE'}


R=random.randint(0,100) #generate random integer
i=0
while i<R:
    keys=list(my_dict2_TRMMAP.keys())
    values=list(my_dict2_TRMMAP.values())
    shuffle(values)
    my_dict2_TRMMAP_random=dict(zip(keys,values)) #create suffled dictionary(mixed values)

    #connect to local Mongo Client
    myclient = pymongo.MongoClient("mongodb://localhost:27017/")

    # create mongo data base "RAN100"
    mydb = myclient["RAN100"]

    mycollection1=mydb["RAN100_collection1"]
    mycollection1.insert_one(my_dict2_TRMMAP_random)


    for document in mycollection1.find():
        print(document)

    i=i+1

print(mycollection1.count_documents({}))
print(mycollection1.count_documents({'Common channel primary path': 'EF'}))