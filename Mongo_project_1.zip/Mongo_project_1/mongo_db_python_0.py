import pymongo
my_dict1_PHBMAP={'BE':'0','AF11':'10','AF12':'12', 'AF13':'14',\
                 'AF21':'18', 'AF22':'20', 'AF23':'22','AF31':'26',\
                'AF32':'28','AF33':'30', 'AF41':'34', 'AF42':'40', 'AF43':'46',\
                 'EF':'48','CS1':'8', 'CS2':'16', 'CS3':'24', 'CS4':'32','CS5':'41', 'CS6':'49', 'CS7':'56'}



#connect to local Mongo Client
myclient = pymongo.MongoClient("mongodb://localhost:27017/")


# create mongo data base "RAN1"
mydb = myclient["RAN1"]


mycollection1=mydb["RAN1_collection1"]
#mycollection1.insert_one(my_dict1_PHBMAP)
print(myclient.list_database_names())

#2nd run error duplicate
mycollection2=mydb.create_collection("RAN2_collection2")
print(mydb.list_collection_names())

# mycollection1.drop()
# mycollection2.drop()