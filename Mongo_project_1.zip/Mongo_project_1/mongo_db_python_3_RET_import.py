import csv,json,pymongo

def csv_to_json(csv_file_name):  #convert csv to json
    csvfile = open(csv_file_name,'r')
    jsonfile = open('RET_Data.json', 'w')

    fieldnames=('NE_name',	'RET_DEVICE_NO',	'RET_DEVICE_NAME,') #csv column headers

    reader = csv.DictReader( csvfile, fieldnames)
    reader_list_format=[ row for row in reader ]
    out = json.dumps( reader_list_format[1::] )
    jsonfile.write(out)
    jsonfile.close()

    json1_file = open('RET_Data.json')
    json1_str = json1_file.read()
    json1_data = json.loads(json1_str)
    return json1_data
    # print(json1_str)
    # print(json1_data)

def create_DB_collection(dbName,collectionName,data_to_import):
    myclient = pymongo.MongoClient("mongodb://localhost:27017/")

    # create mongo data base
    mydb = myclient[dbName]
    print(myclient.list_database_names())

    mycollection=mydb[collectionName]
    print(mydb.list_collection_names())

    i=0
    while i<len(data_to_import):
       mycollection.insert_one(data_to_import[i])
       del data_to_import[i]['_id']
       i=i+1

    return mydb,mycollection

DATA=csv_to_json("RET_data_export.csv")                              #covert csv file to json format
(MYDB,MYCOL)=create_DB_collection("RET_DB","RET_collection",DATA)  #import json to DB/collection wanted
